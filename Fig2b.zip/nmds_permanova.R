# ============================================================
# NMDS Analysis and PERMANOVA for Cattle Gut Microbiome
#
# Performs non-metric multidimensional scaling (NMDS) on species-level
# relative abundance data, generates NMDS ordination plots with
# confidence ellipses, and tests group separation using PERMANOVA
# (pairwise.adonis).
#
# Input:
#   Cattle_NMDS_species.csv          - Species abundance matrix
#                                      (rows = samples, columns = species)
#   data_scores_Cattle_all_Type.csv  - Sample metadata with group labels
#                                      (columns: name, NMDS1, NMDS2, Type, Type2)
#
# Output:
#   NMDS_results/
#     NMDS_scores.csv                - NMDS coordinates
#     NMDS_plot.pdf / .png           - Ordination plot
#     PERMANOVA_Before_vs_Final.txt  - PERMANOVA result (Type: Before vs Final)
#     PERMANOVA_Diarrhoea_vs_Non.txt - PERMANOVA result (Type2: Diarrhoea vs Non)
#
# Note on experimental design:
#   After_1297 (untreated reference) is classified as "Before" group,
#   resulting in Before (n=7) vs Final (n=5) unbalanced comparison.
#
# Requirements: vegan, ggplot2, pairwiseAdonis
# ============================================================

library(vegan)
library(ggplot2)
library(pairwiseAdonis)

# --- Output directory ---
dir.create("./NMDS_results", showWarnings = FALSE)

# ============================================================
# 1. Load data
# ============================================================

pc <- read.csv("Cattle_NMDS_species.csv", header = TRUE)
cat("Data dimensions:", dim(pc), "\n")

# Extract community matrix (columns 2 onward = species abundances)
com <- pc[, 2:ncol(pc)]
m_com <- as.matrix(com)

# ============================================================
# 2. NMDS ordination
# ============================================================

set.seed(123)
nmds <- metaMDS(m_com, distance = "bray")
cat("Stress:", nmds$stress, "\n")

# Extract site scores
data.scores <- as.data.frame(scores(nmds)$sites)
data.scores$Sample <- pc$name

# Save scores
write.csv(data.scores, "./NMDS_results/NMDS_scores.csv", row.names = FALSE)

# ============================================================
# 3. Load metadata and merge
# ============================================================

meta <- read.csv("data_scores_Cattle_all_Type.csv")

# Merge NMDS scores with metadata
data.scores$Type  <- meta$Type
data.scores$Type2 <- meta$Type2

# ============================================================
# 4. NMDS plot (Before vs Final)
# ============================================================

p_nmds <- ggplot(data.scores, aes(x = NMDS1, y = NMDS2, fill = Type)) +
    geom_point(shape = 21, color = "black", size = 3, stroke = 0.8) +
    stat_ellipse(
        aes(colour = Type),
        geom = "polygon",
        linetype = 3,
        alpha = 1/5
    ) +
    scale_fill_manual(values = c("steelblue", "tomato")) +
    scale_colour_manual(values = c("steelblue", "tomato")) +
    labs(x = "NMDS1", y = "NMDS2", fill = "Group", colour = "Group") +
    theme_bw() +
    theme(
        panel.grid = element_blank(),
        axis.text  = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"),
        legend.text  = element_text(size = 12),
        legend.title = element_text(size = 14, face = "bold")
    )

# Display
print(p_nmds)

# Save
ggsave("./NMDS_results/NMDS_plot.pdf", plot = p_nmds,
       width = 6, height = 5, device = "pdf")
ggsave("./NMDS_results/NMDS_plot.png", plot = p_nmds,
       width = 6, height = 5, dpi = 300)

# ============================================================
# 5. PERMANOVA (pairwise.adonis)
# ============================================================

# --- Before vs Final (Type) ---
cat("\nPERMANOVA: Before vs Final\n")
perm_type <- pairwise.adonis(com, meta$Type)
print(perm_type)

sink("./NMDS_results/PERMANOVA_Before_vs_Final.txt")
cat("PERMANOVA: Before vs Final (pairwise.adonis)\n")
cat("Note: After_1297 (untreated reference) is included in Before group\n")
cat("Before group: n=7, Final group: n=5\n\n")
print(perm_type)
sink()

# --- Diarrhoea vs Non (Type2) ---
cat("\nPERMANOVA: Diarrhoea vs Non\n")
perm_type2 <- pairwise.adonis(com, meta$Type2)
print(perm_type2)

sink("./NMDS_results/PERMANOVA_Diarrhoea_vs_Non.txt")
cat("PERMANOVA: Diarrhoea vs Non (pairwise.adonis)\n\n")
print(perm_type2)
sink()

cat("\nAnalysis complete. Results saved in ./NMDS_results/\n")
