# ============================================================
# NMDS Analysis, PERMANOVA, and Visualisation
# for Cattle Gut Microbiome
#
# Performs NMDS ordination (Bray-Curtis), generates multiple
# plot styles, and tests group separation using PERMANOVA.
#
# Input:
#   Cattle_NMDS_species.csv           - Species abundance matrix
#   data.scores_Cattle_all_Type.csv   - Metadata (Type, Type2)
#
# Output:
#   NMDS_results/
#     NMDS_scores.csv
#     scatter_*.pdf / .png            - Multiple plot styles
#     PERMANOVA_*.txt                 - PERMANOVA results
#
# Requirements: vegan, ggplot2, pairwiseAdonis
# ============================================================

library(vegan)
library(ggplot2)
library(pairwiseAdonis)

# --- Output directory ---
dir.create("./NMDS_results", showWarnings = FALSE)

# ============================================================
# 1. Load data and run NMDS
# ============================================================

pc <- read.csv("Cattle_NMDS_species.csv", header = TRUE)
cat("Data dimensions:", dim(pc), "\n")

com <- pc[, 2:ncol(pc)]
m_com <- as.matrix(com)

set.seed(123)
nmds <- metaMDS(m_com, distance = "bray")
cat("Stress:", nmds$stress, "\n")

# Extract scores
data.scores <- as.data.frame(scores(nmds)$sites)
data.scores$Sample <- pc$name
write.csv(data.scores, "./NMDS_results/NMDS_scores.csv", row.names = FALSE)

# ============================================================
# 2. Load metadata
# ============================================================

values <- read.csv("data.scores_Cattle_all_Type.csv")
group  <- values$Type

# ============================================================
# 3. Prepare label data frame
#    Before group (n=7, incl. After_1297) vs Final (n=5)
# ============================================================

values_dataframe <- data.frame(
    values,
    label = factor(
        c(rep("Before", 7), rep("After", 5)),
        levels = c("Before", "Final")
    )
)

# ============================================================
# 4. All plot styles
# ============================================================

# --- Style 1: Colour by group (8 colours) ---
scatter_plot1 <- ggplot(values, aes(x = NMDS1, y = NMDS2, fill = group)) +
    geom_point(shape = 21, color = "black", size = 2, stroke = 1) +
    theme_bw() +
    xlab("NMDS1") + ylab("NMDS2") +
    scale_fill_manual(values = c("red", "green", "blue", "orange",
                                 "brown", "violet", "lightblue", "pink"))

print(scatter_plot1)
ggsave("./NMDS_results/scatter_colour.pdf",  plot = scatter_plot1, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_colour.png",  plot = scatter_plot1, dpi = 300, height = 3, width = 4.5)

# --- Style 2: + dotted ellipse ---
scatter_plot1_2 <- scatter_plot1 +
    stat_ellipse(linetype = "dotted")

print(scatter_plot1_2)
ggsave("./NMDS_results/scatter_ellipse_dotted.pdf", plot = scatter_plot1_2, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_ellipse_dotted.png", plot = scatter_plot1_2, dpi = 300, height = 3, width = 4.5)

# --- Style 3: + solid ellipse ---
scatter_plot1_3 <- scatter_plot1 +
    stat_ellipse()

print(scatter_plot1_3)
ggsave("./NMDS_results/scatter_ellipse_solid.pdf", plot = scatter_plot1_3, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_ellipse_solid.png", plot = scatter_plot1_3, dpi = 300, height = 3, width = 4.5)

# --- Style 4: + norm ellipse, dashed ---
scatter_plot1_4 <- scatter_plot1 +
    stat_ellipse(type = "norm", linetype = 3)

print(scatter_plot1_4)
ggsave("./NMDS_results/scatter_ellipse_norm.pdf", plot = scatter_plot1_4, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_ellipse_norm.png", plot = scatter_plot1_4, dpi = 300, height = 3, width = 4.5)

# --- Style 5: filled polygon ellipse (alpha=1/4) ---
scatter_plot1_5 <- scatter_plot1 +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/4)

print(scatter_plot1_5)
ggsave("./NMDS_results/scatter_polygon.pdf", plot = scatter_plot1_5, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_polygon.png", plot = scatter_plot1_5, dpi = 300, height = 3, width = 4.5)

# --- Style 6: polygon + transparent background, no grid ---
scatter_plot1_6 <- scatter_plot1 +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/4) +
    theme(
        panel.background = element_rect(fill = "transparent", colour = "black"),
        panel.grid = element_blank()
    )

print(scatter_plot1_6)
ggsave("./NMDS_results/scatter_polygon_transparent.pdf", plot = scatter_plot1_6, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_polygon_transparent.png", plot = scatter_plot1_6, dpi = 300, height = 3, width = 4.5)

# --- Style 6b: polygon + transparent, 12 colours ---
scatter_plot1_6_12 <- ggplot(values, aes(x = NMDS1, y = NMDS2, fill = group)) +
    geom_point(shape = 21, color = "black", size = 2, stroke = 1) +
    theme_bw() +
    xlab("NMDS1") + ylab("NMDS2") +
    scale_fill_manual(values = c("red", "green", "blue", "orange",
                                 "brown", "violet", "lightblue", "pink",
                                 "lightgreen", "gray", "black", "white")) +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/4) +
    theme(
        panel.background = element_rect(fill = "transparent", colour = "black"),
        panel.grid = element_blank()
    )

print(scatter_plot1_6_12)
ggsave("./NMDS_results/scatter_polygon_12col.pdf", plot = scatter_plot1_6_12, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_polygon_12col.png", plot = scatter_plot1_6_12, dpi = 300, height = 3, width = 4.5)

# --- Style 7: pastel colours (alpha=1/5) ---
scatter_plot1_7 <- ggplot(values, aes(x = NMDS1, y = NMDS2, fill = group)) +
    geom_point(shape = 21, color = "black", size = 1.5, stroke = 1) +
    theme_bw() +
    xlab("NMDS1") + ylab("NMDS2") +
    scale_fill_manual(values = c("pink", "green", "violet", "gray",
                                 "brown", "yellow", "orange", "white")) +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/5) +
    theme(
        panel.background = element_rect(fill = "transparent"),
        panel.grid = element_blank()
    )

print(scatter_plot1_7)
ggsave("./NMDS_results/scatter_pastel.pdf", plot = scatter_plot1_7, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_pastel.png", plot = scatter_plot1_7, dpi = 300, height = 3, width = 4.5)

# --- Style 8: pastel + simple axis labels ---
scatter_plot1_8 <- ggplot(values, aes(x = NMDS1, y = NMDS2, fill = group)) +
    geom_point(shape = 21, color = "black", size = 1.5, stroke = 1) +
    theme_bw() +
    xlab("NMDS1") + ylab("NMDS2") +
    scale_fill_manual(values = c("pink", "green", "violet", "gray",
                                 "brown", "yellow", "orange", "white")) +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/5) +
    theme(
        panel.background = element_rect(fill = "transparent"),
        panel.grid = element_blank()
    )

print(scatter_plot1_8)
ggsave("./NMDS_results/scatter_pastel_simple.pdf", plot = scatter_plot1_8, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_pastel_simple.png", plot = scatter_plot1_8, dpi = 300, height = 3, width = 4.5)

# --- Style 9: values_dataframe with group fill + label colour ---
scatter_plot1_9 <- ggplot(values_dataframe, aes(x = NMDS1, y = NMDS2, fill = group)) +
    geom_point(shape = 21, color = "black", size = 1.5, stroke = 1) +
    theme_bw() +
    xlab("NMDS1") + ylab("NMDS2") +
    scale_fill_manual(values = c("pink", "green", "violet", "gray",
                                 "brown", "yellow", "orange", "white")) +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/5) +
    theme(
        panel.background = element_rect(fill = "transparent"),
        panel.grid = element_blank()
    )

print(scatter_plot1_9)
ggsave("./NMDS_results/scatter_dataframe_group.pdf", plot = scatter_plot1_9, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_dataframe_group.png", plot = scatter_plot1_9, dpi = 300, height = 3, width = 4.5)

# --- Style 10: values_dataframe with label fill ---
scatter_plot1_10 <- ggplot(values_dataframe, aes(x = NMDS1, y = NMDS2,
                                                  fill = label, colour = label)) +
    geom_point(shape = 21, color = "black", size = 1.5, stroke = 1) +
    theme_bw() +
    xlab("NMDS1") + ylab("NMDS2") +
    stat_ellipse(geom = "polygon", linetype = 3, alpha = 1/5) +
    theme(
        panel.background = element_rect(fill = "transparent"),
        panel.grid = element_blank()
    )

print(scatter_plot1_10)
ggsave("./NMDS_results/scatter_dataframe_label.pdf", plot = scatter_plot1_10, dpi = 300, height = 3, width = 4.5)
ggsave("./NMDS_results/scatter_dataframe_label.png", plot = scatter_plot1_10, dpi = 300, height = 3, width = 4.5)

# --- Style 11: Publication-style (2-colour, bold text) ---
p_pub <- ggplot(data.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_point(size = 4, aes(shape = values$Type, colour = values$Type)) +
    theme(
        axis.text.y    = element_text(colour = "black", size = 12, face = "bold"),
        axis.text.x    = element_text(colour = "black", size = 12, face = "bold"),
        legend.text    = element_text(size = 12, face = "bold", colour = "black"),
        legend.position = "right",
        axis.title.y   = element_text(face = "bold", size = 14),
        axis.title.x   = element_text(face = "bold", size = 14, colour = "black"),
        legend.title   = element_text(size = 14, colour = "black", face = "bold"),
        panel.background = element_blank(),
        panel.border   = element_rect(colour = "black", fill = NA, linewidth = 1.2),
        legend.key     = element_blank()
    ) +
    labs(x = "NMDS1", colour = "Type", y = "NMDS2", shape = "Type") +
    scale_colour_manual(values = c("blue", "red")) +
    stat_ellipse(aes(colour = values$Type), linetype = "dotted")

print(p_pub)
ggsave("./NMDS_results/scatter_publication_2col.pdf", plot = p_pub, dpi = 300, height = 5, width = 6)
ggsave("./NMDS_results/scatter_publication_2col.png", plot = p_pub, dpi = 300, height = 5, width = 6)

# --- Style 12: Publication-style (4-colour) ---
p_pub4 <- ggplot(data.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_point(size = 4, aes(shape = values$Type, colour = values$Type)) +
    theme(
        axis.text.y    = element_text(colour = "black", size = 12, face = "bold"),
        axis.text.x    = element_text(colour = "black", size = 12, face = "bold"),
        legend.text    = element_text(size = 12, face = "bold", colour = "black"),
        legend.position = "right",
        axis.title.y   = element_text(face = "bold", size = 14),
        axis.title.x   = element_text(face = "bold", size = 14, colour = "black"),
        legend.title   = element_text(size = 14, colour = "black", face = "bold"),
        panel.background = element_blank(),
        panel.border   = element_rect(colour = "black", fill = NA, linewidth = 1.2),
        legend.key     = element_blank()
    ) +
    labs(x = "NMDS1", colour = "Type", y = "NMDS2", shape = "Type") +
    scale_colour_manual(values = c("blue", "red", "violet", "pink")) +
    stat_ellipse(aes(colour = values$Type), linetype = "dotted")

print(p_pub4)
ggsave("./NMDS_results/scatter_publication_4col.pdf", plot = p_pub4, dpi = 300, height = 5, width = 6)
ggsave("./NMDS_results/scatter_publication_4col.png", plot = p_pub4, dpi = 300, height = 5, width = 6)

# ============================================================
# 5. PERMANOVA (pairwise.adonis)
# ============================================================

# --- Before vs Final (Type) ---
cat("\nPERMANOVA: Before vs Final\n")
perm_type <- pairwise.adonis(com, values$Type)
print(perm_type)

sink("./NMDS_results/PERMANOVA_Before_vs_Final.txt")
cat("PERMANOVA: Before vs Final (pairwise.adonis)\n")
cat("Note: After_1297 (untreated reference) is included in Before group\n")
cat("Before group: n=7, Final group: n=5\n\n")
print(perm_type)
sink()

# --- Diarrhoea vs Non (Type2) ---
cat("\nPERMANOVA: Diarrhoea vs Non\n")
perm_type2 <- pairwise.adonis(com, values$Type2)
print(perm_type2)

sink("./NMDS_results/PERMANOVA_Diarrhoea_vs_Non.txt")
cat("PERMANOVA: Diarrhoea vs Non (pairwise.adonis)\n\n")
print(perm_type2)
sink()

# --- Before_dir vs Final_nondir (Type3, excluding Ref) ---
cat("\nPERMANOVA: Before_dir vs Final_nondir (Ref excluded)\n")
mask_type3 <- values$Type3 != "Ref"
perm_type3 <- pairwise.adonis(com[mask_type3, ], values$Type3[mask_type3])
print(perm_type3)

sink("./NMDS_results/PERMANOVA_Type3_noRef.txt")
cat("PERMANOVA: Before_dir vs Final_nondir (Ref excluded)\n")
cat("Before_dir:   diarrhoeic calves before administration (n=4)\n")
cat("Final_nondir: recovered calves after administration (n=4)\n")
cat("Ref (n=4) excluded from analysis\n\n")
print(perm_type3)
sink()

# ============================================================
# Summary
# ============================================================
cat("\n")
cat("============================================================\n")
cat("Analysis complete.\n")
cat("============================================================\n")
cat("Stress:", nmds$stress, "\n")
cat("Output directory: ./NMDS_results/\n")
cat("\nPlot files generated:\n")
cat("  scatter_colour.*              - Basic colour by group\n")
cat("  scatter_ellipse_dotted.*      - Dotted ellipse\n")
cat("  scatter_ellipse_solid.*       - Solid ellipse\n")
cat("  scatter_ellipse_norm.*        - Normal distribution ellipse\n")
cat("  scatter_polygon.*             - Filled polygon ellipse\n")
cat("  scatter_polygon_transparent.* - Polygon, transparent bg\n")
cat("  scatter_polygon_12col.*       - Polygon, 12 colours\n")
cat("  scatter_pastel.*              - Pastel colours\n")
cat("  scatter_pastel_simple.*       - Pastel, simple labels\n")
cat("  scatter_dataframe_group.*     - Group-based fill\n")
cat("  scatter_dataframe_label.*     - Label-based fill\n")
cat("  scatter_publication_2col.*    - Publication style (2 col)\n")
cat("  scatter_publication_4col.*    - Publication style (4 col)\n")
