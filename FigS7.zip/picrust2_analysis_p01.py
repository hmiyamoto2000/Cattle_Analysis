#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PICRUSt2 Differential Abundance Analysis

Performs Mann-Whitney U tests on PICRUSt2-predicted functional profiles
across multiple group comparisons (administration, disease status, time),
with FDR correction and keyword-based functional screening.

Results are saved at two significance thresholds (p < 0.05 and p < 0.10).

Usage:
    python3 picrust2_analysis.py <fileA.csv> <fileB.csv>(Cattle_list260313_dironly_UTF.csv)

Arguments:
    fileA.csv - PICRUSt2 output file
                Column 1: pathway/function name
                Remaining columns: sample abundances

    fileB.csv - Sample metadata
                Column 1: sample  - sample name
                Column 2: env     - before/after
                Column 3: dir     - disease status (0 = no disease / 1 = disease)
                Column 4: ad      - administration (0 = no / 1 = yes)

Output (per comparison):
    <base>_<comparison>_all.csv              - Full results
    <base>_<comparison>_significant_p05.csv  - Significant (p < 0.05)
    <base>_<comparison>_significant_p10.csv  - Significant (p < 0.10)
    <base>_<comparison>_top50.csv            - Top 50 by p-value

Statistical method:
    - Mann-Whitney U test (two-sided)
    - Benjamini-Hochberg FDR correction

Author: H. Miyamoto
"""

import sys
import pandas as pd
import numpy as np
from scipy import stats
import warnings

warnings.filterwarnings('ignore')


# ============================================================
# 1. Load files
# ============================================================
def load_files(fileA, fileB):
    print("\n" + "=" * 60)
    print("Loading files...")
    print("=" * 60)

    # Load PICRUSt2 file (tab or comma delimited)
    try:
        df_func = pd.read_csv(fileA, sep='\t', index_col=0)
    except Exception:
        df_func = pd.read_csv(fileA, sep=',', index_col=0)

    # Load metadata (auto-detect delimiter)
    with open(fileB, 'r', encoding='utf-8-sig') as f:
        first_line = f.readline()
    sep = '\t' if '\t' in first_line else ','
    df_meta = pd.read_csv(fileB, sep=sep, encoding='utf-8-sig')

    print(f"Metadata: {df_meta.shape[1]} columns, {df_meta.shape[0]} rows")

    # Standardise column names (expected order: sample, env, dir, ad)
    df_meta.columns = ['sample', 'env', 'dir', 'ad']

    print(f"  Functional data: {df_func.shape[0]} functions x "
          f"{df_func.shape[1]} samples")
    print(f"  Metadata: {df_meta.shape[0]} samples")
    print(f"\nGroup composition:")
    print(f"  env: {df_meta['env'].value_counts().to_dict()}")
    print(f"  ad : {df_meta['ad'].value_counts().to_dict()} "
          f"(0 = no administration / 1 = administered)")
    print(f"  dir: {df_meta['dir'].value_counts().to_dict()} "
          f"(0 = no disease / 1 = disease)")
    print(f"\nDetailed group composition:")
    print(df_meta.groupby(['env', 'ad', 'dir']).size().to_string())

    return df_func, df_meta


# ============================================================
# 2. Align samples
# ============================================================
def align_samples(df_func, df_meta):
    print("\n" + "=" * 60)
    print("Checking sample alignment...")
    print("=" * 60)

    common_samples = list(set(df_func.columns) & set(df_meta['sample']))
    missing = list(set(df_meta['sample']) - set(df_func.columns))

    if missing:
        print(f"  WARNING: Samples in metadata but not in PICRUSt2: {missing}")

    df_func = df_func[common_samples]
    df_meta = df_meta[df_meta['sample'].isin(common_samples)]

    print(f"  Samples used for analysis: {len(common_samples)}")

    return df_func, df_meta


# ============================================================
# 3. Group comparison (Mann-Whitney U test)
# ============================================================
def compare_groups(df_func, group1_label, group2_label,
                   group1_samples, group2_samples):
    results = []

    for func in df_func.index:
        g1 = df_func.loc[func, group1_samples].values.astype(float)
        g2 = df_func.loc[func, group2_samples].values.astype(float)

        try:
            stat, pval = stats.mannwhitneyu(g1, g2, alternative='two-sided')
        except Exception:
            pval = np.nan

        mean1 = np.mean(g1)
        mean2 = np.mean(g2)

        if mean1 > 0 and mean2 > 0:
            log2fc = np.log2(mean2 / mean1)
        elif mean2 > mean1:
            log2fc = np.inf
        elif mean1 > mean2:
            log2fc = -np.inf
        else:
            log2fc = 0

        results.append({
            'function': func,
            f'mean_{group1_label}': mean1,
            f'mean_{group2_label}': mean2,
            'log2FC': log2fc,
            'p_value': pval
        })

    df_result = pd.DataFrame(results)
    df_result = df_result.dropna(subset=['p_value'])

    # FDR correction (Benjamini-Hochberg)
    pvals = df_result['p_value'].values
    n = len(pvals)
    sorted_idx = np.argsort(pvals)
    fdr = np.zeros(n)
    for i, idx in enumerate(sorted_idx):
        fdr[idx] = pvals[idx] * n / (i + 1)
    fdr = np.minimum(fdr, 1.0)
    df_result['FDR'] = fdr
    df_result = df_result.sort_values('p_value')

    return df_result


# ============================================================
# 4. Run all comparisons
# ============================================================
def run_analysis(df_func, df_meta):
    print("\n" + "=" * 60)
    print("Running statistical analysis...")
    print("=" * 60)

    all_results = {}

    def get_samples(filters):
        mask = pd.Series([True] * len(df_meta), index=df_meta.index)
        for col, val in filters.items():
            mask = mask & (df_meta[col] == val)
        return df_meta[mask]['sample'].tolist()

    def run_comparison(label, group1_label, group2_label, s1, s2):
        if len(s1) > 0 and len(s2) > 0:
            print(f"\n  {label}")
            print(f"   {group1_label} (n={len(s1)}) vs "
                  f"{group2_label} (n={len(s2)})")
            result = compare_groups(
                df_func, group1_label, group2_label, s1, s2)
            all_results[label] = result
            print(f"   Significant (p < 0.05) : "
                  f"{len(result[result['p_value'] < 0.05])} functions")
            print(f"   Significant (p < 0.10) : "
                  f"{len(result[result['p_value'] < 0.10])} functions")
            print(f"   Significant (FDR < 0.05): "
                  f"{len(result[result['FDR'] < 0.05])} functions")
        else:
            print(f"\n  WARNING: {label}: insufficient samples, skipped")

    # --- Basic comparisons ---
    run_comparison(
        'administered_vs_non_administered',
        'non_administered(ad=0)', 'administered(ad=1)',
        get_samples({'ad': 0}),
        get_samples({'ad': 1}))

    run_comparison(
        'after_vs_before',
        'before', 'after',
        get_samples({'env': 'before'}),
        get_samples({'env': 'after'}))

    run_comparison(
        'disease_vs_no_disease',
        'no_disease(dir=0)', 'disease(dir=1)',
        get_samples({'dir': 0}),
        get_samples({'dir': 1}))

    # --- Administration x timepoint ---
    run_comparison(
        'administered_after_vs_before',
        'ad1_before', 'ad1_after',
        get_samples({'ad': 1, 'env': 'before'}),
        get_samples({'ad': 1, 'env': 'after'}))

    run_comparison(
        'non_administered_after_vs_before',
        'ad0_before', 'ad0_after',
        get_samples({'ad': 0, 'env': 'before'}),
        get_samples({'ad': 0, 'env': 'after'}))

    # --- Disease x administration x timepoint (key comparisons) ---
    run_comparison(
        'disease_administered_after_vs_before',
        'dir1_ad1_before', 'dir1_ad1_after',
        get_samples({'dir': 1, 'ad': 1, 'env': 'before'}),
        get_samples({'dir': 1, 'ad': 1, 'env': 'after'}))

    run_comparison(
        'disease_non_administered_after_vs_before',
        'dir1_ad0_before', 'dir1_ad0_after',
        get_samples({'dir': 1, 'ad': 0, 'env': 'before'}),
        get_samples({'dir': 1, 'ad': 0, 'env': 'after'}))

    run_comparison(
        'disease_after_administered_vs_non',
        'dir1_after_ad0', 'dir1_after_ad1',
        get_samples({'dir': 1, 'env': 'after', 'ad': 0}),
        get_samples({'dir': 1, 'env': 'after', 'ad': 1}))

    run_comparison(
        'no_disease_after_administered_vs_non',
        'dir0_after_ad0', 'dir0_after_ad1',
        get_samples({'dir': 0, 'env': 'after', 'ad': 0}),
        get_samples({'dir': 0, 'env': 'after', 'ad': 1}))

    # Most directly relevant to disease improvement
    run_comparison(
        'disease_vs_no_disease_administered_after',
        'no_disease_ad1_after', 'disease_ad1_after',
        get_samples({'dir': 0, 'ad': 1, 'env': 'after'}),
        get_samples({'dir': 1, 'ad': 1, 'env': 'after'}))

    return all_results


# ============================================================
# 5. Keyword-based functional screening (p < 0.05 and p < 0.10)
# ============================================================
def search_keywords(all_results):
    print("\n" + "=" * 60)
    print("Searching for keywords of interest (p < 0.10)...")
    print("=" * 60)

    keywords = [
        'terpen', 'terpene',
        'lanthi', 'lantibiotic',
        'amino', 'aminoisobutyric', 'AIB',
        'peptide', 'bacteriocin',
        'fengycin', 'lipopeptide',
        'methyl', 'methyltransfer',
        'protease', 'peptidase',
        'cysteine', 'radical SAM',
        'antibiotic', 'antimicrobial',
        'RiPP', 'quorum'
    ]

    for comparison_name, df_result in all_results.items():
        print(f"\n  {comparison_name}:")
        found_any = False

        for kw in keywords:
            mask = df_result['function'].str.contains(
                kw, case=False, na=False)
            hits = df_result[mask]

            if len(hits) > 0:
                # p < 0.05
                sig_05 = hits[hits['p_value'] < 0.05]
                # 0.05 <= p < 0.10
                sig_10 = hits[
                    (hits['p_value'] >= 0.05) & (hits['p_value'] < 0.10)
                ]

                if len(sig_05) > 0 or len(sig_10) > 0:
                    found_any = True

                for _, row in sig_05.iterrows():
                    print(f"   '{kw}' (p < 0.05): "
                          f"{row['function'][:60]} "
                          f"| p={row['p_value']:.4f} "
                          f"| FDR={row['FDR']:.4f} "
                          f"| log2FC={row['log2FC']:.2f}")

                for _, row in sig_10.iterrows():
                    print(f"   '{kw}' (p < 0.10): "
                          f"{row['function'][:60]} "
                          f"| p={row['p_value']:.4f} "
                          f"| FDR={row['FDR']:.4f} "
                          f"| log2FC={row['log2FC']:.2f}")

        if not found_any:
            print("   No significant functions found for keywords of interest")


# ============================================================
# 6. Save results
# ============================================================
def save_results(all_results, fileA):
    print("\n" + "=" * 60)
    print("Saving results...")
    print("=" * 60)

    base_name = fileA.replace('.csv', '').replace('.tsv', '')

    for comparison_name, df_result in all_results.items():

        # Full results
        output_file = f"{base_name}_{comparison_name}_all.csv"
        df_result.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"  Full results: {output_file}")

        # Significant (p < 0.05)
        sig_05 = df_result[df_result['p_value'] < 0.05]
        if len(sig_05) > 0:
            sig_file = f"{base_name}_{comparison_name}_significant_p05.csv"
            sig_05.to_csv(sig_file, index=False, encoding='utf-8-sig')
            print(f"  p < 0.05:     {sig_file} ({len(sig_05)} functions)")
        else:
            print(f"  p < 0.05:     none")

        # Significant (p < 0.10)
        sig_10 = df_result[df_result['p_value'] < 0.10]
        if len(sig_10) > 0:
            sig_file = f"{base_name}_{comparison_name}_significant_p10.csv"
            sig_10.to_csv(sig_file, index=False, encoding='utf-8-sig')
            print(f"  p < 0.10:     {sig_file} ({len(sig_10)} functions)")
        else:
            print(f"  p < 0.10:     none")

        # Top 50
        top_file = f"{base_name}_{comparison_name}_top50.csv"
        df_result.head(50).to_csv(
            top_file, index=False, encoding='utf-8-sig')
        print(f"  Top 50:       {top_file}")


# ============================================================
# Main
# ============================================================
def main():
    if len(sys.argv) != 3:
        print("Usage: python3 picrust2_analysis.py <fileA.csv> <fileB.csv>")
        sys.exit(1)

    fileA = sys.argv[1]
    fileB = sys.argv[2]

    print("\n" + "=" * 60)
    print("PICRUSt2 Differential Abundance Analysis")
    print("=" * 60)
    print(f"Functional data: {fileA}")
    print(f"Metadata:        {fileB}")

    df_func, df_meta = load_files(fileA, fileB)
    df_func, df_meta = align_samples(df_func, df_meta)
    all_results = run_analysis(df_func, df_meta)
    search_keywords(all_results)
    save_results(all_results, fileA)

    print("\n" + "=" * 60)
    print("Analysis complete.")
    print("=" * 60)
    print("\nOutput files:")
    print("  *_all.csv              - Full comparison results")
    print("  *_significant_p05.csv  - Significant functions (p < 0.05)")
    print("  *_significant_p10.csv  - Significant functions (p < 0.10)")
    print("  *_top50.csv            - Top 50 functions by p-value")


if __name__ == '__main__':
    main()
