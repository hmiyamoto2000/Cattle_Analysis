#!/usr/bin/env python3
"""
EC Log2FC Mirror Bar Graph v3
Comparison of with/without administration and with/without disease is displayed side by side on the left and right sides

How to use:
    python3 ec_log2fc_mirror_v3.py ad.csv dir.csv [width] [height] [fontsize] 9 10 14

引数（全てオプション）:
Arguments (all optional):
    width : Width of the figure (inches, default: 14)
    height : Figure height (inches, default: automatic)
    fontsize : base font size (pt, default: 11)
例:
    python3 ec_log2fc_mirror_v3.py ad.csv dir.csv
    python3 ec_log2fc_mirror_v3.py ad.csv dir.csv 16 10
    python3 ec_log2fc_mirror_v3.py ad.csv dir.csv 16 10 12

Fonts:
    Preferential use of Helvetica. If you don't have it installed,
    Arial → DejaVu Sans fell back in that order.
    Check command: python3 -c "import matplotlib.font_manager as fm; print([f.name for f in fm.fontManager.ttflist if 'Helvetica' in f.name])"
    
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.font_manager as fm
import numpy as np
import sys
import os

# ============================================================
# Font settings（Helvetica → Arial → DejaVu Sans）
# ============================================================
def set_font():
    available = [f.name for f in fm.fontManager.ttflist]
    if 'Helvetica' in available:
        plt.rcParams['font.family'] = 'Helvetica'
        return 'Helvetica'
    elif 'Arial' in available:
        plt.rcParams['font.family'] = 'Arial'
        return 'Arial'
    else:
        plt.rcParams['font.family'] = 'DejaVu Sans'
        return 'DejaVu Sans'

FONT_USED = set_font()
plt.rcParams['axes.linewidth'] = 1.2

# ============================================================
# color settings
# ============================================================
COLOR_INC_05  = '#E74C3C'
COLOR_DEC_05  = '#2980B9'
COLOR_INC_10  = '#F1948A'
COLOR_DEC_10  = '#85C1E9'
COLOR_INF_POS = '#C0392B'
COLOR_INF_NEG = '#1A5276'

# ============================================================
# Data Loading
# ============================================================
def load_csv(filepath):
    try:
        df = pd.read_csv(filepath, sep='\t')
        if df.shape[1] < 3:
            df = pd.read_csv(filepath, sep=',')
    except Exception:
        df = pd.read_csv(filepath, sep=',')
    df.columns = [c.strip() for c in df.columns]
    df = df.rename(columns={
        df.columns[0]: 'function',
        df.columns[3]: 'log2FC',
        df.columns[4]: 'p_value'
    })
    return df

# ============================================================
# Title settings（mean_ removal・Japanese→English）
# ============================================================
def clean_title(col_name):
    name = col_name.strip()
    if name.startswith('mean_'):
        name = name[5:]
    replacements = {
        '投与あり': 'Administered',
        '投与なし': 'Control',
        '病気あり': 'Disease',
        '病気なし': 'Healthy',
    }
    for jp, en in replacements.items():
        name = name.replace(jp, en)
    # 括弧を除去
    name = name.replace('(', '').replace(')', '')
    return name.strip()

# ============================================================
# pvalue filtering・ABC sorting
# ============================================================
def prepare_df(df, p_threshold=0.1):
    df = df[df['p_value'] < p_threshold].copy()
    df['log2FC_num'] = pd.to_numeric(
        df['log2FC'], errors='coerce')
    df['is_pos_inf'] = np.isposinf(df['log2FC_num'])
    df['is_neg_inf'] = np.isneginf(df['log2FC_num'])
    df['is_inf']     = df['is_pos_inf'] | df['is_neg_inf']
    # ABCorder（upside-down）
    df = df.sort_values('function', ascending=False)
    return df.reset_index(drop=True)

# ============================================================
# Color assignment
# ============================================================
def get_color(row):
    if row['is_pos_inf']:
        return COLOR_INF_POS
    if row['is_neg_inf']:
        return COLOR_INF_NEG
    if row['p_value'] < 0.05:
        return COLOR_INC_05 if row['log2FC_num'] > 0 \
               else COLOR_DEC_05
    else:
        return COLOR_INC_10 if row['log2FC_num'] > 0 \
               else COLOR_DEC_10

# ============================================================
# Horizontal bar graph drawing (1 panel)
# ============================================================
def draw_panel(ax, df, title, max_abs, fs):
    """
    fs: Font size dictionary
        fs['base'], fs['title'], fs['tick'],
        fs['star'], fs['nd'], fs['xlabel']
    """
    if df.empty:
        ax.text(0.5, 0.5, 'No data',
                transform=ax.transAxes,
                ha='center', va='center',
                fontsize=fs['base'])
        ax.set_title(title, fontsize=fs['title'],
                     fontweight='bold', pad=10)
        return

    ecs    = df['function'].tolist()
    colors = [get_color(row) for _, row in df.iterrows()]

    # inf を max_abs * 1.1 に置き換え
    plot_vals = []
    for _, row in df.iterrows():
        if row['is_pos_inf']:
            plot_vals.append(max_abs * 1.1)
        elif row['is_neg_inf']:
            plot_vals.append(-max_abs * 1.1)
        else:
            plot_vals.append(row['log2FC_num'])

    ax.barh(ecs, plot_vals,
            color=colors,
            edgecolor='white',
            linewidth=0.5,
            height=0.65)

    # Asterisk ND label (no number)
    for i, (_, row) in enumerate(df.iterrows()):
        fc = plot_vals[i]
        pv = row['p_value']

        if row['is_pos_inf']:
            ax.text(max_abs * 1.25, i, 'ND',
                    va='center', ha='left',
                    fontsize=fs['nd'],
                    color=COLOR_INF_POS,
                    fontweight='bold')
        elif row['is_neg_inf']:
            ax.text(-max_abs * 1.25, i, 'ND',
                    va='center', ha='right',
                    fontsize=fs['nd'],
                    color=COLOR_INF_NEG,
                    fontweight='bold')
        else:
            if pv < 0.001:   star = '***'
            elif pv < 0.01:  star = '**'
            elif pv < 0.05:  star = '*'
            else:             star = ''

            if star:
                offset = max_abs * 0.04
                ha = 'left'  if fc >= 0 else 'right'
                x  = fc + offset if fc >= 0 else fc - offset
                ax.text(x, i, star,
                        va='center', ha=ha,
                        fontsize=fs['star'],
                        color='black',
                        fontweight='bold')

    # Axis Settings
    ax.axvline(0, color='black',
               linewidth=1.0, zorder=3)
    ax.set_xlim(-max_abs * 1.5, max_abs * 1.5)
    ax.set_xlabel('Log$_2$ Fold Change',
                  fontsize=fs['xlabel'])
    ax.set_title(title, fontsize=fs['title'],
                 fontweight='bold', pad=8)
    ax.grid(axis='x', linestyle='--',
            alpha=0.4, zorder=0)
    ax.set_axisbelow(True)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(axis='y', labelsize=fs['tick'])
    ax.tick_params(axis='x', labelsize=fs['tick'])

# ============================================================
# main treatment
# ============================================================
def main():
    if len(sys.argv) < 3:
        print("howto: python3 ec_log2fc_mirror_v3.py "
              "ad.csv dir.csv [width] [height] [fontsize]")
        sys.exit(1)

    file_ad  = sys.argv[1]
    file_dir = sys.argv[2]

    # Option Arguments
    fig_w    = float(sys.argv[3]) if len(sys.argv) > 3 else 14.0
    fig_h    = float(sys.argv[4]) if len(sys.argv) > 4 else None
    fontsize = float(sys.argv[5]) if len(sys.argv) > 5 else 11.0

    # fontsize setting（Set relative to base size）
    fs = {
        'base'    : fontsize,
        'title'   : fontsize + 1,
        'tick'    : fontsize - 1,
        'star'    : fontsize + 1,
        'nd'      : fontsize - 1,
        'xlabel'  : fontsize,
        'legend'  : fontsize - 2,
        'suptitle': fontsize + 2,
    }

    print(f"font: {FONT_USED}")
    print(f"fig_size: width={fig_w}, height={'auto' if fig_h is None else fig_h}")
    print(f"font_size: {fontsize}pt")

    # data loading
    df_ad  = load_csv(file_ad)
    df_dir = load_csv(file_dir)
    print(f"ad_data:  {df_ad.columns.tolist()}")
    print(f"dir_data: {df_dir.columns.tolist()}")

    # p<0.1filering・ABCorder sorting
    df_ad_plot  = prepare_df(df_ad,  p_threshold=0.1)
    df_dir_plot = prepare_df(df_dir, p_threshold=0.1)

    print(f"ad_comparison ECnumber: {len(df_ad_plot)}")
    print(f"dir_comparison ECnumber: {len(df_dir_plot)}")

    # common max_abs（axis scale）
    finite_vals = pd.concat([
        df_ad_plot.loc[~df_ad_plot['is_inf'], 'log2FC_num'],
        df_dir_plot.loc[~df_dir_plot['is_inf'], 'log2FC_num']
    ]).abs()
    max_abs = (finite_vals.max() * 1.1
               if not finite_vals.empty else 6.0)

    # Automatic calculation of figure height
    if fig_h is None:
        n_rows = max(len(df_ad_plot), len(df_dir_plot))
        fig_h  = max(4.0, n_rows * 0.6 + 2.5)

    plt.rcParams['font.size'] = fontsize

    fig, (ax1, ax2) = plt.subplots(
        1, 2,
        figsize=(fig_w, fig_h),
        sharey=False)

    # Panel Title Generation
    ad_cols  = [c for c in df_ad.columns
                if c not in ['function', 'log2FC', 'p_value']]
    dir_cols = [c for c in df_dir.columns
                if c not in ['function', 'log2FC', 'p_value']]

    title_ad = (f"{clean_title(ad_cols[1])} vs "
                f"{clean_title(ad_cols[0])}"
                if len(ad_cols) >= 2
                else "Administered vs Control")

    title_dir = (f"{clean_title(dir_cols[0])} vs "
                 f"{clean_title(dir_cols[1])}"
                 if len(dir_cols) >= 2
                 else "Healthy vs Disease")

    draw_panel(ax1, df_ad_plot,  title_ad,  max_abs, fs)
    draw_panel(ax2, df_dir_plot, title_dir, max_abs, fs)

    # legend
    legend_elements = [
        mpatches.Patch(facecolor=COLOR_INC_05,
                       label='Increased (p<0.05)'),
        mpatches.Patch(facecolor=COLOR_DEC_05,
                       label='Decreased (p<0.05)'),
        mpatches.Patch(facecolor=COLOR_INC_10,
                       label='Increased (0.05<=p<0.1)'),
        mpatches.Patch(facecolor=COLOR_DEC_10,
                       label='Decreased (0.05<=p<0.1)'),
        mpatches.Patch(facecolor=COLOR_INF_POS,
                       label='Newly detected (ND->detected)'),
        mpatches.Patch(facecolor=COLOR_INF_NEG,
                       label='Disappeared (detected->ND)'),
    ]
    fig.legend(handles=legend_elements,
               loc='lower center',
               bbox_to_anchor=(0.5, -0.06),
               ncol=3,
               fontsize=fs['legend'],
               frameon=True,
               framealpha=0.9,
               edgecolor='lightgray')

    fig.suptitle(
        'Gut microbial functional changes '
        '(PICRUSt2 predicted EC activities)',
        fontsize=fs['suptitle'],
        fontweight='bold',
        y=1.02)

    plt.tight_layout()

    # save
    output_folder = 'ec_log2fc_plots'
    os.makedirs(output_folder, exist_ok=True)

    base = os.path.splitext(
           os.path.basename(file_ad))[0]
    pdf_path = os.path.join(output_folder,
               f'{base}_mirror_v3.pdf')
    png_path = os.path.join(output_folder,
               f'{base}_mirror_v3.png')

    plt.savefig(pdf_path, dpi=300,
                bbox_inches='tight')
    plt.savefig(png_path, dpi=300,
                bbox_inches='tight')
    plt.close()

    print(f"\n save:")
    print(f"   PDF: {pdf_path}")
    print(f"   PNG: {png_path}")

if __name__ == '__main__':
    main()
