#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROC AUC Variable Filtering and Curve Visualisation

Computes ROC AUC for candidate variables identified by Cliff's delta
analysis, filters by AUC threshold, and generates multi-panel ROC
curve plots with Youden optimal points.

Usage:
    python3 roc_filter.py <input.csv>(Matabolite_whole.csv) <Step2_Cliffs_large.csv>

Arguments:
    input.csv              - Raw metabolite data (wide format)
                             Column 1: variable name
                             Remaining: Before_1, ..., After_1, ...
    Step2_Cliffs_large.csv - Output from pipeline_ttest_cliff.py

Output (./Anal/ directory):
    ROC_AUC_results.csv        - AUC values for all candidate variables
    ROC_filtered_variables.csv - Variables with AUC >= 0.875
    ROC_curves.png / .pdf      - Multi-panel ROC curve plots

AUC classification:
    >= 0.9    excellent
    >= 0.875  good
    >= 0.75   acceptable
    >= 0.625  poor
    < 0.625   fail

Author: H. Miyamoto
"""

import sys
import os
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import warnings

warnings.filterwarnings("ignore")

# =========================
# Font settings (Helvetica preferred)
# =========================
available_fonts = [f.name for f in fm.fontManager.ttflist]
if 'Helvetica' in available_fonts:
    plt.rcParams['font.family'] = 'Helvetica'
elif 'Arial' in available_fonts:
    plt.rcParams['font.family'] = 'Arial'
else:
    plt.rcParams['font.family'] = 'DejaVu Sans'

plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype']  = 42

# =========================
# Font size settings
# =========================
FS_TITLE    = 14
FS_TICK     = 12
FS_LEGEND   = 10
FS_SUPTITLE = 16
FS_ANNOT    = 8

# ===========================
# Command-line arguments
# ===========================
if len(sys.argv) != 3:
    print("Usage: python3 roc_filter.py <input.csv> <Step2_Cliffs_large.csv>")
    sys.exit(1)

raw_csv   = sys.argv[1]
cliff_csv = sys.argv[2]

os.makedirs("./Anal", exist_ok=True)

# ===========================
# Load data
# ===========================
print("Loading data...")
raw_df   = pd.read_csv(raw_csv)
cliff_df = pd.read_csv(cliff_csv)

# Standardise column names
raw_df.columns = [
    c.replace("Beforel_", "Bef_")
     .replace("Before_",  "Bef_")
     .replace("After_",   "Aft_")
    for c in raw_df.columns
]

name_col    = raw_df.columns[0]
gene_names  = raw_df[name_col].tolist()
target_vars = cliff_df["name"].tolist()

bef_cols = [c for c in raw_df.columns if c.startswith("Bef_")]
aft_cols = [c for c in raw_df.columns if c.startswith("Aft_")]

print(f"Cliff's large variables: {len(target_vars)}")
print(f"Before columns: {len(bef_cols)}  |  After columns: {len(aft_cols)}")


# ===========================
# ROC / AUC / Sensitivity / Specificity calculation
# ===========================
def calc_roc_full(before_vals, after_vals):
    """
    Compute ROC AUC with Youden optimal sensitivity and specificity.

    Returns:
        auc, fpr, tpr, best_sensitivity, best_specificity
    """
    before = np.array(before_vals, dtype=float)
    after  = np.array(after_vals,  dtype=float)
    before = before[~np.isnan(before)]
    after  = after[~np.isnan(after)]

    if len(before) == 0 or len(after) == 0:
        return np.nan, None, None, np.nan, np.nan

    y_true  = np.array([0] * len(before) + [1] * len(after))
    y_score = np.concatenate([before, after])

    if np.all(y_score == y_score[0]):
        return 0.5, [0, 1], [0, 1], np.nan, np.nan

    try:
        auc = roc_auc_score(y_true, y_score)
        if auc < 0.5:
            auc     = 1 - auc
            y_score = -y_score

        fpr, tpr, thresholds = roc_curve(y_true, y_score)

        # Youden index: maximise Sensitivity + Specificity - 1
        youden    = tpr - fpr
        best_idx  = np.argmax(youden)
        best_sens = tpr[best_idx]
        best_spec = 1 - fpr[best_idx]

        return auc, fpr, tpr, best_sens, best_spec
    except Exception:
        return np.nan, None, None, np.nan, np.nan


def auc_label(auc):
    """Classify AUC value."""
    if np.isnan(auc):
        return "NaN"
    elif auc >= 0.9:
        return "excellent"
    elif auc >= 0.875:
        return "good"
    elif auc >= 0.75:
        return "acceptable"
    elif auc >= 0.625:
        return "poor"
    else:
        return "fail"


# ===========================
# Compute AUC for each variable
# ===========================
print("\nComputing AUC...")

results  = []
roc_data = {}

for var in target_vars:
    if var not in gene_names:
        print(f"   WARNING: {var} not found. Skipping.")
        continue

    idx         = gene_names.index(var)
    before_vals = raw_df.iloc[idx][bef_cols].values.astype(float)
    after_vals  = raw_df.iloc[idx][aft_cols].values.astype(float)

    auc, fpr, tpr, best_sens, best_spec = calc_roc_full(before_vals, after_vals)
    roc_data[var] = {
        "fpr": fpr, "tpr": tpr, "auc": auc,
        "sensitivity": best_sens, "specificity": best_spec
    }

    cliff_row = cliff_df[cliff_df["name"] == var].iloc[0]

    results.append({
        "name":           var,
        "AUC":            round(auc, 4) if not np.isnan(auc) else np.nan,
        "AUC_label":      auc_label(auc),
        "Sensitivity":    round(best_sens, 3) if not np.isnan(best_sens) else np.nan,
        "Specificity":    round(best_spec, 3) if not np.isnan(best_spec) else np.nan,
        "Ttest_paired_p": cliff_row["Ttest_paired_p"],
        "Fold_Change":    cliff_row["Fold_Change"],
        "Cliffs_delta":   cliff_row["Cliffs_delta"],
        "direction":      cliff_row["direction"],
    })

roc_df = pd.DataFrame(results)
roc_df = roc_df.sort_values("AUC", ascending=False).reset_index(drop=True)


# ===========================
# Filter by AUC threshold
# ===========================
auc_threshold = 0.875
filtered_df   = roc_df[roc_df["AUC"] >= auc_threshold].copy().reset_index(drop=True)


# ===========================
# Save CSV
# ===========================
roc_df.to_csv("./Anal/ROC_AUC_results.csv", index=False)
filtered_df.to_csv("./Anal/ROC_filtered_variables.csv", index=False)


# ===========================
# Generate ROC curve plots
# ===========================
print("\nGenerating ROC curve plots...")

n_vars = len(roc_df)
n_cols = 5
n_rows = int(np.ceil(n_vars / n_cols))

fig, axes = plt.subplots(n_rows, n_cols,
                         figsize=(n_cols * 3.2, n_rows * 3.2))
axes = np.array(axes).flatten()

# Colour scheme: increase/decrease/below threshold
COLOR_INC = "tomato"
COLOR_DEC = "steelblue"
COLOR_LOW = "lightgray"

for i, (_, row) in enumerate(roc_df.iterrows()):
    ax        = axes[i]
    var       = row["name"]
    auc       = row["AUC"]
    direction = row["direction"]
    sens      = row["Sensitivity"]
    spec      = row["Specificity"]
    data      = roc_data.get(var, {})
    fpr       = data.get("fpr")
    tpr       = data.get("tpr")

    # Curve colour: above threshold -> direction-coded; below -> grey
    if auc >= auc_threshold:
        curve_color = COLOR_INC if direction == "increase" else COLOR_DEC
    else:
        curve_color = COLOR_LOW

    # ROC curve
    if fpr is not None and tpr is not None:
        ax.plot(fpr, tpr, color=curve_color, linewidth=2.0)

        # Youden optimal point
        if not np.isnan(sens) and not np.isnan(spec):
            best_fpr = 1 - spec
            best_tpr = sens
            ax.scatter(best_fpr, best_tpr,
                       color=curve_color, s=40, zorder=5,
                       edgecolors='black', linewidths=0.5)
    else:
        ax.plot([0, 1], [0, 1], color="gray", linewidth=1)

    # Diagonal (random classifier)
    ax.plot([0, 1], [0, 1], 'k--', linewidth=0.7, alpha=0.4)

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.05)
    ax.set_xlabel("1 - Specificity (FPR)", fontsize=FS_TICK)
    ax.set_ylabel("Sensitivity (TPR)",     fontsize=FS_TICK)
    ax.tick_params(labelsize=FS_TICK)

    # Sensitivity / Specificity annotation
    info_text = (
        f"Sens={sens:.2f}  Spec={spec:.2f}"
        if not (np.isnan(sens) or np.isnan(spec))
        else ""
    )
    ax.text(0.97, 0.08, info_text,
            transform=ax.transAxes,
            fontsize=FS_ANNOT, ha='right', va='bottom',
            color='dimgray')

    # Title: variable name + AUC + direction
    dir_label   = "inc" if direction == "increase" else "dec"
    title_color = curve_color if auc >= auc_threshold else "gray"
    ax.set_title(
        f"{var}\nAUC={auc:.3f} ({row['AUC_label']}, {dir_label})",
        fontsize=FS_TITLE, color=title_color, pad=3
    )
    ax.grid(True, alpha=0.3)

# Hide unused subplots
for j in range(i + 1, len(axes)):
    axes[j].set_visible(False)

# Global legend
legend_handles = [
    plt.Line2D([0], [0], color=COLOR_INC, linewidth=2,
               label="increase (AUC >= threshold)"),
    plt.Line2D([0], [0], color=COLOR_DEC, linewidth=2,
               label="decrease (AUC >= threshold)"),
    plt.Line2D([0], [0], color=COLOR_LOW, linewidth=2,
               label=f"AUC < {auc_threshold}"),
    plt.Line2D([0], [0], marker='o', color='w',
               markerfacecolor='gray', markersize=6,
               markeredgecolor='black', label="Youden optimal point"),
]

fig.suptitle(
    f"ROC Curves  |  AUC threshold = {auc_threshold}  |  "
    f"red = increase, blue = decrease",
    fontsize=FS_SUPTITLE, y=1.0
)
plt.tight_layout(rect=[0, 0.06, 1, 0.97])
fig.legend(handles=legend_handles,
           loc='lower center', ncol=4,
           fontsize=FS_LEGEND, frameon=True,
           bbox_to_anchor=(0.5, 0.0))

png_path = "./Anal/ROC_curves.png"
pdf_path = "./Anal/ROC_curves.pdf"
plt.savefig(png_path, dpi=300, bbox_inches='tight')
plt.savefig(pdf_path, bbox_inches='tight')
print(f"Saved: {png_path}")
print(f"Saved: {pdf_path}")
plt.show()


# ===========================
# Summary
# ===========================
print(f"\n{'=' * 60}")
print(f"Analysis complete.")
print(f"{'=' * 60}")

print(f"\n--- AUC per variable (descending) ---")
print(roc_df[[
    "name", "AUC", "AUC_label", "Sensitivity", "Specificity",
    "Ttest_paired_p", "direction"
]].to_string(index=False))

print(f"\n--- Variables with AUC >= {auc_threshold}: "
      f"{len(filtered_df)} variables ---")
if len(filtered_df) > 0:
    print(filtered_df[[
        "name", "AUC", "AUC_label", "Sensitivity", "Specificity", "direction"
    ]].to_string(index=False))
else:
    print("None found.")

print(f"\nSaved:")
print(f"  ./Anal/ROC_AUC_results.csv          ({len(roc_df)} variables)")
print(f"  ./Anal/ROC_filtered_variables.csv   ({len(filtered_df)} variables)")
print(f"  ./Anal/ROC_curves.png / .pdf")
