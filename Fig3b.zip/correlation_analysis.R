# ============================================================
# Spearman Correlation Analysis with corrplot
# Input: Cattle_metabolite.csv
# Output: PDF/PNG plots + CSV tables
# ============================================================

# --- Libraries ---
library(reshape2)
library(grid)
library(lattice)
library(corrplot)
library(RColorBrewer)
library(PerformanceAnalytics)
library(ggcorrplot)
library(Hmisc)

# --- Data ---
r_p <- read.csv("Cattle_metabolite.csv")
r <- r_p[, -1]
cat("Data dimensions:", dim(r), "\n")

# --- Spearman correlation + p-values ---
res <- rcorr(as.matrix(r), type = "spearman")
mcor <- res$r
pval <- res$P

# --- Correlation summary ---
cor_vals <- mcor[upper.tri(mcor)]
cat("\n=== Correlation summary ===\n")
print(summary(cor_vals))
cat("\n=== |r| distribution ===\n")
print(table(
  cut(abs(cor_vals),
      breaks = c(0, 0.2, 0.4, 0.6, 0.8, 1),
      labels = c("<0.2", "0.2-0.4", "0.4-0.6", "0.6-0.8", ">0.8"))
))

# --- p-value matrix (for corrplot2 style) ---
cor.mtest <- function(mat, method) {
  mat <- as.matrix(mat)
  n <- ncol(mat)
  p.mat <- matrix(NA, n, n)
  diag(p.mat) <- 0
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      tmp <- cor.test(mat[, i], mat[, j], method = method)
      p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
    }
  }
  colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
  p.mat
}

p.mat <- cor.mtest(r, method = "spearman")

# --- Color palettes ---
col_rdblu  <- colorRampPalette(brewer.pal(11, "RdBu"))
col_rdblu_rev <- colorRampPalette(rev(brewer.pal(11, "RdBu")))

col1 <- colorRampPalette(c("#7F0000", "red", "#FF7F00", "yellow", "white",
                           "cyan", "#007FFF", "blue", "#00007F"))
col2 <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7",
                           "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061"))
col3 <- colorRampPalette(c("red", "white", "blue"))
col4 <- colorRampPalette(c("#7F0000", "red", "#FF7F00", "yellow", "#7FFF7F",
                           "cyan", "#007FFF", "blue", "#00007F"))
col_bwr <- colorRampPalette(c("blue", "white", "red"))
col_corrplot2 <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))

# --- Output settings ---
pdf_w <- 10
pdf_h <- 10
png_w <- 10
png_h <- 10
png_res <- 300

# ============================================================
# Section 1: Basic corrplots (full / upper / lower)
# ============================================================

# 1a. Full - blue-white-red
pdf("corrplot_full.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor, col = col_bwr(100), tl.col = "black")
dev.off()

png("corrplot_full.png", width = png_w, height = png_h, units = "in", res = png_res)
corrplot(mcor, col = col_bwr(100), tl.col = "black")
dev.off()

# 1b. Upper
pdf("corrplot_upper.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor, type = "upper", tl.col = "black", tl.cex = 1.0, tl.srt = 45)
dev.off()

png("corrplot_upper.png", width = png_w, height = png_h, units = "in", res = png_res)
corrplot(mcor, type = "upper", tl.col = "black", tl.cex = 1.0, tl.srt = 45)
dev.off()

# 1c. Lower - default
pdf("corrplot_lower.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor, type = "lower", tl.col = "black", tl.cex = 1.0, tl.srt = 45)
dev.off()

png("corrplot_lower.png", width = png_w, height = png_h, units = "in", res = png_res)
corrplot(mcor, type = "lower", tl.col = "black", tl.cex = 1.0, tl.srt = 45)
dev.off()

# 1d. Lower - RdBu palette
pdf("corrplot_lower_RdBu.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor, type = "lower", tl.col = "black", tl.cex = 1.0, tl.srt = 45,
         col = col_rdblu(100))
dev.off()

png("corrplot_lower_RdBu.png", width = png_w, height = png_h, units = "in", res = png_res)
corrplot(mcor, type = "lower", tl.col = "black", tl.cex = 1.0, tl.srt = 45,
         col = col_rdblu(100))
dev.off()

# 1e. Lower - RdBu reversed
pdf("corrplot_lower_RdBu_rev.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor, type = "lower", tl.col = "black", tl.cex = 1.0, tl.srt = 45,
         col = col_rdblu_rev(100))
dev.off()

# 1f. Lower - Helvetica font
pdf("corrplot_lower_helvetica.pdf", family = "Helvetica", width = 7, height = 7)
corrplot(mcor, type = "lower", tl.col = "black", tl.cex = 1.0, tl.srt = 45,
         col = col_rdblu_rev(100))
dev.off()

# ============================================================
# Section 2: Significance-marked corrplots
# ============================================================

# 2a. Asterisk for non-significant pairs
pdf("corrplot_significance_asterisk.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor,
         method    = "color",
         col       = col_rdblu(100),
         tl.col    = "black",
         tl.cex    = 1.0,
         tl.srt    = 45,
         p.mat     = pval,
         sig.level = 0.05,
         insig     = "pch",
         pch       = "*",
         pch.cex   = 0.8)
dev.off()

png("corrplot_significance_asterisk.png", width = png_w, height = png_h, units = "in", res = png_res)
corrplot(mcor,
         method    = "color",
         col       = col_rdblu(100),
         tl.col    = "black",
         tl.cex    = 1.0,
         tl.srt    = 45,
         p.mat     = pval,
         sig.level = 0.05,
         insig     = "pch",
         pch       = "*",
         pch.cex   = 0.8)
dev.off()

# ============================================================
# Section 3: Color palette comparison (col1-col4)
# ============================================================

palette_list <- list(col1 = col1, col2 = col2, col3 = col3, col4 = col4)

for (pal_name in names(palette_list)) {
  pal_func <- palette_list[[pal_name]]

  # --- Simple version (no significance filter) ---
  pdf(paste0("corrplot_simple_", pal_name, ".pdf"), width = pdf_w, height = pdf_h)
  corrplot(mcor, col = pal_func(100), tl.col = "black", tl.cex = 1.0, tl.srt = 45)
  dev.off()

  png(paste0("corrplot_simple_", pal_name, ".png"), width = png_w, height = png_h, units = "in", res = png_res)
  corrplot(mcor, col = pal_func(100), tl.col = "black", tl.cex = 1.0, tl.srt = 45)
  dev.off()

  # --- With significance + hclust order + coefficients ---
  pdf(paste0("corrplot_sig_hclust_", pal_name, ".pdf"), width = pdf_w, height = pdf_h)
  corrplot(mcor,
           method       = "color",
           col          = pal_func(200),
           number.font  = 2,
           mar          = c(0, 0, 1, 0),
           number.cex   = 0.7,
           type         = "full",
           order        = "hclust",
           addCoef.col  = "black",
           tl.col       = "black",
           tl.srt       = 45,
           p.mat        = p.mat,
           sig.level    = 0.05,
           insig        = "blank",
           diag         = FALSE)
  dev.off()

  png(paste0("corrplot_sig_hclust_", pal_name, ".png"), width = png_w, height = png_h, units = "in", res = png_res)
  corrplot(mcor,
           method       = "color",
           col          = pal_func(200),
           number.font  = 2,
           mar          = c(0, 0, 1, 0),
           number.cex   = 0.7,
           type         = "full",
           order        = "hclust",
           addCoef.col  = "black",
           tl.col       = "black",
           tl.srt       = 45,
           p.mat        = p.mat,
           sig.level    = 0.05,
           insig        = "blank",
           diag         = FALSE)
  dev.off()
}

# ============================================================
# Section 4: corrplot2 style (upper / lower)
# ============================================================

# 4a. Upper
pdf("corrplot2_upper.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor,
         method       = "color",
         col          = col_corrplot2(200),
         number.font  = 1,
         number.cex   = 1,
         mar          = c(0, 0, 0, 0),
         type         = "upper",
         order        = "original",
         addCoef.col  = "black",
         tl.col       = "black",
         tl.srt       = 75,
         p.mat        = p.mat,
         sig.level    = 0.05,
         insig        = "blank",
         diag         = FALSE)
dev.off()

# 4b. Lower
pdf("corrplot2_lower.pdf", width = pdf_w, height = pdf_h)
corrplot(mcor,
         method       = "color",
         col          = col_corrplot2(200),
         number.font  = 1,
         number.cex   = 1,
         mar          = c(0, 0, 0, 0),
         type         = "lower",
         order        = "original",
         addCoef.col  = "black",
         tl.col       = "black",
         tl.srt       = 75,
         p.mat        = p.mat,
         sig.level    = 0.05,
         insig        = "blank",
         diag         = FALSE)
dev.off()

#Mark1
pdf("ggcorrplot_sig.pdf", width = 10, height = 10)
print(
  ggcorrplot(mcor,
             type = "lower",
             method = "square",
             lab = TRUE,
             lab_size = 3,
             p.mat = pval,
             sig.level = 0.05,
             insig = "blank",
             colors = c("blue", "white", "red"),
             title = "Spearman correlation (non-significant pairs removed)")
)
dev.off()

#Mark2
pdf("ggcorrplot_sig_large.pdf", width = 10, height = 10)
print(
  ggcorrplot(mcor,
             type = "lower",
             method = "square",
             lab = TRUE,
             lab_size = 3,
             p.mat = pval,
             sig.level = 0.05,
             insig = "blank",
             colors = c("blue", "white", "red"),
             title = "Spearman correlation") +
    theme(
      axis.text.x = element_text(size = 14),
      axis.text.y = element_text(size = 14),
      plot.title  = element_text(size = 18, face = "bold"),
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14)
    )
)
dev.off()


# ============================================================
# Section 5: CSV output
# ============================================================

# --- Flatten correlation matrix ---
flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row    = rownames(cormat)[row(cormat)[ut]],
    column = colnames(cormat)[col(cormat)[ut]],
    cor    = cormat[ut],
    p      = pmat[ut]
  )
}

flat <- flattenCorrMatrix(mcor, pval)

# All pairwise correlations
flat$significant <- ifelse(!is.na(flat$p) & flat$p < 0.05, "yes", "no")
write.csv(flat, "all_correlations.csv", row.names = FALSE)

# Strong + significant only
strong <- subset(flat, abs(cor) >= 0.4 & p < 0.05)
write.csv(strong, "strong_significant_correlations.csv", row.names = FALSE)

# Pairwise values only
write.csv(data.frame(correlation = cor_vals),
          "pairwise_spearman_correlations.csv", row.names = FALSE)

# Full correlation matrix
write.csv(mcor, "correlation_matrix.csv", row.names = TRUE)

# ============================================================
cat("\nDone. Output files:\n")
cat("  PDF/PNG: corrplot_*.pdf/png, corrplot2_*.pdf\n")
cat("  CSV:     all_correlations.csv\n")
cat("           strong_significant_correlations.csv\n")
cat("           pairwise_spearman_correlations.csv\n")
cat("           correlation_matrix.csv\n")
