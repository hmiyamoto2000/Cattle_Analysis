#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cliff's Delta Bubble Chart Visualisation

Generates a bubble chart showing Cliff's delta effect sizes with 95%
bootstrap confidence intervals. Bubble size reflects -log10(p-value)
from paired t-test; colour indicates direction of change.

Usage:
    python3 plot_cliffs_bubble.py <Step2_Cliffs_delta.csv> [fig_width]

Examples:
    python3 plot_cliffs_bubble.py ./Anal/Step2_Cliffs_delta.csv        # default width
    python3 plot_cliffs_bubble.py ./Anal/Step2_Cliffs_delta.csv 12     # width = 12

Input CSV columns (from pipeline_ttest_cliff.py output):
    name, Ttest_paired_p, Cliffs_delta, CI_low, CI_high, direction, ...

Output:
    Cliff_delta_plot.png  (300 dpi)
    Cliff_delta_plot.pdf

Author: H. Miyamoto
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np
import sys
import os

# =========================
# Font settings (Helvetica preferred)
# =========================
available_fonts = [f.name for f in fm.fontManager.ttflist]
if 'Helvetica' in available_fonts:
    plt.rcParams['font.family'] = 'Helvetica'
elif 'Arial' in available_fonts:
    plt.rcParams['font.family'] = 'Arial'
else:
    plt.rcParams['font.family'] = 'DejaVu Sans'

plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype']  = 42

# =========================
# Font size settings
# =========================
FIG_WIDTH       = 8
FS_XLABEL       = 16
FS_YLABEL       = 18
FS_TITLE        = 12
FS_TICK         = 12
FS_LEGEND       = 9
FS_LEGEND_TITLE = 9

# =========================
# 1. Argument parsing
# =========================
if len(sys.argv) < 2:
    print("Usage: python3 plot_cliffs_bubble.py "
          "<Step2_Cliffs_delta.csv> [fig_width]")
    sys.exit(1)

file_path = sys.argv[1]
fig_width = float(sys.argv[2]) if len(sys.argv) >= 3 else FIG_WIDTH

print(f"Settings: fig_width = {fig_width}")

# =========================
# 2. Load CSV
# =========================
df = pd.read_csv(file_path)

df = df.rename(columns={
    "name":           "feature",
    "Cliffs_delta":   "delta",
    "CI_low":         "ci_low",
    "CI_high":        "ci_high",
    "Ttest_paired_p": "pvalue",
})

df = df.sort_values("pvalue", ascending=False).reset_index(drop=True)

# =========================
# 3. Bubble size and colour
# =========================
bubble_size = -np.log10(df['pvalue'] + 1e-10) * 200
colors = df['direction'].map({
    'increase': 'tomato',
    'decrease': 'steelblue'
})

# =========================
# 4. Create plot
# =========================
fig_height = max(6, len(df) * 0.45)
fig, ax = plt.subplots(figsize=(fig_width, fig_height))

# Bubble scatter plot
ax.scatter(
    df['delta'], df['feature'],
    s=bubble_size,
    alpha=0.7,
    color=colors,
    edgecolors='black',
    linewidths=0.5
)

# Confidence interval lines
for _, row in df.iterrows():
    ax.plot(
        [row['ci_low'], row['ci_high']],
        [row['feature'], row['feature']],
        color='gray', linewidth=2, zorder=0
    )

# Zero reference line
ax.axvline(x=0, color='black', linestyle='--', linewidth=1)

# x-axis range
ax.set_xlim(-1.3, 1.3)

# Labels and title
ax.set_xlabel("Cliff's delta", fontsize=FS_XLABEL)
ax.set_ylabel("Metabolite",    fontsize=FS_YLABEL)
ax.set_title(
    "Cliff's delta with 95% CI\n"
    "(bubble size ~ -log10(p), "
    "red = increase, blue = decrease)",
    fontsize=FS_TITLE
)
ax.tick_params(axis='both', labelsize=FS_TICK)

# =========================
# 5. Legend (bubble size reference)
# =========================
legend_pvals  = [0.05, 0.01, 0.001]
legend_labels = ["p = 0.05", "p = 0.01", "p = 0.001"]
legend_sizes  = [-np.log10(p) * 200 for p in legend_pvals]

legend_handles = []
for p, label, s in zip(legend_pvals, legend_labels, legend_sizes):
    h = ax.scatter([], [], s=s,
                   color='lightgray',
                   edgecolors='black',
                   label=label)
    legend_handles.append(h)

legend = ax.legend(
    handles=legend_handles,
    title="p-value (t-test)",
    title_fontsize=FS_LEGEND_TITLE,
    scatterpoints=1,
    frameon=True,
    fontsize=FS_LEGEND,
    loc='lower left',
    handlelength=2.0,
    handleheight=2.5,
    borderpad=1.2,
    labelspacing=1.5,
    handletextpad=1.0,
    markerscale=1.0,
)

legend.get_frame().set_linewidth(0.8)
legend.get_frame().set_alpha(0.9)

# Grid
ax.grid(axis='x', linestyle=':', alpha=0.4)
ax.grid(axis='y', linestyle=':', alpha=0.2)

plt.tight_layout()

# =========================
# 6. Save
# =========================
out_dir  = os.path.dirname(file_path) if os.path.dirname(file_path) else "."
png_path = os.path.join(out_dir, "Cliff_delta_plot.png")
pdf_path = os.path.join(out_dir, "Cliff_delta_plot.pdf")

plt.savefig(png_path, dpi=300, bbox_inches='tight')
plt.savefig(pdf_path, bbox_inches='tight')

print(f"Font used: {plt.rcParams['font.family']}")
print(f"Saved: {png_path}")
print(f"Saved: {pdf_path}")

plt.show()
