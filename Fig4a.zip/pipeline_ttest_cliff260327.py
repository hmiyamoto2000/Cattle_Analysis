#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline: Paired t-test screening on raw data followed by
Cliff's delta effect size evaluation on log-transformed data.

This script performs a two-step variable selection procedure:
  Step 1: Paired t-test on raw data to identify variables with p < 0.10
  Step 2: Cliff's delta with bootstrap 95% CI on log-transformed data
          to evaluate effect size and select final candidate variables

Usage:
    python3 pipeline_ttest_cliff.py <input.csv> Matabolite_whole.csv

Input CSV format (wide format):
    Column 1:       Variable name
    Columns 2-...:  Before_1, Before_2, ..., After_1, After_2, ...

Output (./Anal/ directory):
    Step1_Ttest_raw_p10.csv    - Variables with paired t-test raw p < 0.10
    Step2_Cliffs_delta.csv     - Cliff's delta + 95% CI for all Step 1 variables
    Step2_Cliffs_large.csv     - Final selection: |delta| >= 0.474 and CI excludes zero

Log transformation policy:
    - Values <= 0 are replaced with NaN before log transformation
    - Natural logarithm (np.log) is used
    - Variables where all samples become NaN are skipped

Author: H. Miyamoto
"""

import sys
import os
import numpy as np
import pandas as pd
from scipy.stats import ttest_rel
import warnings

warnings.filterwarnings("ignore")


# ===========================
# Command-line arguments
# ===========================
if len(sys.argv) != 2:
    print("Usage: python3 pipeline_ttest_cliff.py <input.csv>")
    sys.exit(1)

raw_csv = sys.argv[1]
os.makedirs("./Anal", exist_ok=True)


# ===========================
# Load data
# ===========================
print("Loading data...")
raw_df = pd.read_csv(raw_csv)


# ===========================
# Standardise column names
# (Before_/Beforel_ -> Bef_, After_ -> Aft_)
# ===========================
def normalize_cols(df):
    df.columns = [
        c.replace("Beforel_", "Bef_")
         .replace("Before_",  "Bef_")
         .replace("After_",   "Aft_")
        for c in df.columns
    ]
    return df


raw_df = normalize_cols(raw_df)

name_col   = raw_df.columns[0]
gene_names = raw_df[name_col].tolist()

# Extract Before / After arrays
raw_bef = raw_df.filter(regex="^Bef_").values.astype(float)
raw_aft = raw_df.filter(regex="^Aft_").values.astype(float)
n_genes = raw_df.shape[0]

print(f"Raw data: {n_genes} variables, Bef={raw_bef.shape[1]} cols, Aft={raw_aft.shape[1]} cols")

if raw_bef.shape[1] == 0 or raw_aft.shape[1] == 0:
    print("ERROR: No Before/After columns found. Check column names.")
    sys.exit(1)


# ===========================
# Generate log-transformed data
# ===========================
print("\nGenerating log-transformed data...")


def safe_log(arr):
    """Replace values <= 0 with NaN, then apply natural log."""
    arr = arr.copy()
    arr[arr <= 0] = np.nan
    return np.log(arr)


log_bef = safe_log(raw_bef)
log_aft = safe_log(raw_aft)

n_zero_bef = int(np.sum(raw_bef <= 0))
n_zero_aft = int(np.sum(raw_aft <= 0))
if n_zero_bef > 0 or n_zero_aft > 0:
    print(f"  Note: Values <= 0 found: Bef={n_zero_bef} cells, "
          f"Aft={n_zero_aft} cells -> replaced with NaN before log")

print(f"  Log transformation complete: "
      f"Bef_log={log_bef.shape[1]} cols, Aft_log={log_aft.shape[1]} cols")


# ===========================
# Cliff's delta functions
# ===========================
def cliffs_delta_paired(before, after):
    """Compute Cliff's delta for paired samples."""
    d = np.array(after) - np.array(before)
    return (np.sum(d > 0) - np.sum(d < 0)) / len(d)


def bootstrap_ci(before, after, n_boot=10000, alpha=0.05, seed=42):
    """Compute bootstrap confidence interval for Cliff's delta."""
    rng = np.random.default_rng(seed)
    d = np.array(after) - np.array(before)
    n = len(d)
    boot = np.array([
        (lambda bd: (np.sum(bd > 0) - np.sum(bd < 0)) / n)(
            d[rng.integers(0, n, size=n)]
        )
        for _ in range(n_boot)
    ])
    return (
        np.percentile(boot, 100 * alpha / 2),
        np.percentile(boot, 100 * (1 - alpha / 2))
    )


def cliffs_magnitude(delta):
    """Classify Cliff's delta magnitude (Vargha & Delaney, 2000)."""
    a = abs(delta)
    if a < 0.147:
        return "negligible"
    elif a < 0.330:
        return "small"
    elif a < 0.474:
        return "medium"
    else:
        return "large"


# ===========================
# Step 1: Paired t-test on raw data (p < 0.10)
# ===========================
print("\nStep 1: Paired t-test (raw data)...")

step1_rows = []
for i in range(n_genes):
    xp = raw_bef[i]
    yp = raw_aft[i]
    mask = ~np.isnan(xp) & ~np.isnan(yp)
    xp, yp = xp[mask], yp[mask]

    if len(xp) > 1:
        try:
            _, pval = ttest_rel(xp, yp)
        except Exception:
            pval = np.nan
    else:
        pval = np.nan

    step1_rows.append({
        "name":           gene_names[i],
        "Mean_Before":    round(float(np.mean(xp)), 6) if len(xp) > 0 else np.nan,
        "Mean_After":     round(float(np.mean(yp)), 6) if len(yp) > 0 else np.nan,
        "Fold_Change":    round(float(np.mean(yp) / np.mean(xp)), 4)
                          if len(xp) > 0 and np.mean(xp) != 0 else np.nan,
        "Ttest_paired_p": pval,
    })

step1_df  = pd.DataFrame(step1_rows)
alpha_raw = 0.10
sig_df    = step1_df[step1_df["Ttest_paired_p"] < alpha_raw].copy()
sig_df    = sig_df.sort_values("Ttest_paired_p").reset_index(drop=True)

sig_df.to_csv("./Anal/Step1_Ttest_raw_p10.csv", index=False)
print(f"   {len(sig_df)} variables selected at p < {alpha_raw}")
print(f"   Saved: ./Anal/Step1_Ttest_raw_p10.csv")
print(f"   Selected variables: {sig_df['name'].tolist()}")

if len(sig_df) == 0:
    print("No variables passed Step 1 screening. Exiting.")
    sys.exit(0)


# ===========================
# Step 2: Cliff's delta on log-transformed data
# ===========================
print(f"\nStep 2: Cliff's delta (log-transformed data, n_boot=10000)...")

cliff_rows = []
for _, row in sig_df.iterrows():
    name = row["name"]
    try:
        orig_idx = gene_names.index(name)
    except ValueError:
        print(f"   {name} not found. Skipping.")
        continue

    bef_log = log_bef[orig_idx]
    aft_log = log_aft[orig_idx]
    mask    = ~np.isnan(bef_log) & ~np.isnan(aft_log)
    bef_log = bef_log[mask]
    aft_log = aft_log[mask]

    if len(bef_log) < 2:
        print(f"   {name}: insufficient pairs (n={len(bef_log)}). Skipping.")
        continue

    delta         = cliffs_delta_paired(bef_log, aft_log)
    ci_low, ci_hi = bootstrap_ci(bef_log, aft_log)
    ci_crosses_0  = bool(ci_low <= 0 <= ci_hi)

    cliff_rows.append({
        "name":            name,
        "Ttest_paired_p":  round(row["Ttest_paired_p"], 6),
        "Fold_Change":     row["Fold_Change"],
        "Cliffs_delta":    round(delta,  4),
        "CI_low":          round(ci_low, 4),
        "CI_high":         round(ci_hi,  4),
        "CI_crosses_zero": ci_crosses_0,
        "magnitude":       cliffs_magnitude(delta),
        "direction":       "increase" if delta > 0 else "decrease",
        "n_pairs":         int(len(bef_log)),
    })

cliff_df = pd.DataFrame(cliff_rows)
cliff_df = cliff_df.sort_values(
    "Cliffs_delta", key=abs, ascending=False
).reset_index(drop=True)


# ===========================
# Step 3: Final selection (|delta| >= 0.474 and CI excludes zero)
# ===========================
delta_thr = 0.474
final_df = cliff_df[
    (cliff_df["Cliffs_delta"].abs() >= delta_thr) &
    (~cliff_df["CI_crosses_zero"])
].copy().reset_index(drop=True)

cliff_df.to_csv("./Anal/Step2_Cliffs_delta.csv", index=False)
final_df.to_csv("./Anal/Step2_Cliffs_large.csv", index=False)


# ===========================
# Summary
# ===========================
print(f"\n{'=' * 60}")
print(f"Analysis complete.")
print(f"{'=' * 60}")
print(f"Step 1 (t-test raw p < {alpha_raw}):          "
      f"./Anal/Step1_Ttest_raw_p10.csv  ({len(sig_df)} variables)")
print(f"Step 2 (all Cliff's delta):            "
      f"./Anal/Step2_Cliffs_delta.csv  ({len(cliff_df)} variables)")
print(f"Step 2 (final: large + CI excl. zero): "
      f"./Anal/Step2_Cliffs_large.csv  ({len(final_df)} variables)")

if len(cliff_df) > 0:
    print(f"\n--- Step 2: Cliff's delta summary ---")
    print(cliff_df[[
        "name", "Ttest_paired_p", "Cliffs_delta",
        "CI_low", "CI_high", "CI_crosses_zero", "magnitude", "direction"
    ]].to_string(index=False))

if len(final_df) > 0:
    print(f"\n--- Final selected variables ---")
    print(final_df[[
        "name", "Ttest_paired_p", "Cliffs_delta",
        "CI_low", "CI_high", "magnitude", "direction"
    ]].to_string(index=False))
else:
    print(f"\nMedium threshold (|delta| >= 0.330) candidates:")
    med_df = cliff_df[
        (cliff_df["Cliffs_delta"].abs() >= 0.330) &
        (~cliff_df["CI_crosses_zero"])
    ]
    if len(med_df) > 0:
        print(med_df[[
            "name", "Cliffs_delta", "CI_low", "CI_high", "magnitude"
        ]].to_string(index=False))
    else:
        print("   None found. Consider using all Step 1 variables directly.")
