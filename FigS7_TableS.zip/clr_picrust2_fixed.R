#!/usr/bin/env Rscript
# =====================================================================
# CLR Transformation for PICRUSt2 (EC and Pathway)
#
# Reads PICRUSt2 TSV output, applies proper CLR transformation using
# zCompositions + compositions packages, and saves CSV output.
#
# Usage:
#   Rscript clr_picrust2_fixed.R <input.tsv> <output.csv>
#
# Examples:
#   Rscript clr_picrust2_fixed.R pred_metagenome_unstrat.tsv pred_metagenome_clr.csv
#   Rscript clr_picrust2_fixed.R path_abun_unstrat.tsv path_abun_clr.csv
#
# Author: H. Miyamoto
# =====================================================================

suppressPackageStartupMessages({
    library(compositions)
    library(zCompositions)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) {
    stop("Usage: Rscript clr_picrust2_fixed.R <input.tsv> <output.csv>")
}

input_tsv  <- args[1]
output_csv <- args[2]

cat("============================================================\n")
cat("PICRUSt2 CLR Transformation\n")
cat("============================================================\n")
cat(sprintf("Input:  %s\n", input_tsv))
cat(sprintf("Output: %s\n\n", output_csv))

# 1. Read TSV (rows = features, cols = samples)
df <- read.table(input_tsv, sep = "\t", header = TRUE,
                 row.names = 1, check.names = FALSE,
                 stringsAsFactors = FALSE)
cat(sprintf("Raw input: %d features x %d samples\n", nrow(df), ncol(df)))

# 2. Transpose (rows = samples, cols = features)
mat <- t(as.matrix(df))
storage.mode(mat) <- "numeric"

# 3. Remove empty samples
sample_totals <- rowSums(mat)
empty_samples <- rownames(mat)[sample_totals == 0]
if (length(empty_samples) > 0) {
    cat(sprintf("WARNING: Removing %d empty sample(s): %s\n",
                length(empty_samples),
                paste(empty_samples, collapse = ", ")))
    mat <- mat[sample_totals > 0, , drop = FALSE]
}

cat(sprintf("After transpose: %d samples x %d features\n",
            nrow(mat), ncol(mat)))
cat(sprintf("Zero rate: %.1f%%\n", 100 * mean(mat == 0)))

# 4. Prevalence filter (20% to avoid >80% zero columns)
prevalence_threshold <- 0.20
prev <- colSums(mat > 0) / nrow(mat)
kept_idx <- prev >= prevalence_threshold
mat_filt <- mat[, kept_idx, drop = FALSE]
cat(sprintf("After prevalence filter (>= %.0f%%): %d -> %d features\n",
            100 * prevalence_threshold, ncol(mat), ncol(mat_filt)))

# 5. Convert to relative abundance
rel <- mat_filt / rowSums(mat_filt)

# 6. Zero replacement (multRepl for proportional data)
nonzero_min <- min(rel[rel > 0])
dl <- rep(nonzero_min / 2, ncol(rel))
rel_repl <- multRepl(rel, label = 0, dl = dl, z.delete = FALSE)

# 7. CLR transformation
clr_result <- clr(rel_repl)
clr_mat <- as.matrix(unclass(clr_result))

cat(sprintf("CLR matrix: %d samples x %d features\n", nrow(clr_mat), ncol(clr_mat)))
cat(sprintf("CLR range: %.2f to %.2f\n", min(clr_mat), max(clr_mat)))

# 8. Transpose back to features x samples (for Python compatibility)
clr_out <- t(clr_mat)

# Restore original sample names (R may have converted hyphens to periods)
original_samples <- colnames(df)
if (ncol(clr_out) == length(original_samples)) {
    colnames(clr_out) <- original_samples
}

cat(sprintf("Output matrix: %d features x %d samples\n",
            nrow(clr_out), ncol(clr_out)))
cat(sprintf("Sample names: %s\n",
            paste(colnames(clr_out), collapse = ", ")))

# Save (rows = features, cols = samples, first col = function name)
# Save (TSV format, matching original PICRUSt2 output)
write.table(clr_out, output_csv, sep = "\t",
            quote = FALSE, col.names = NA)

cat(sprintf("\nSaved: %s (%d features x %d samples)\n",
            output_csv, nrow(clr_out), ncol(clr_out)))
cat("Done.\n")
