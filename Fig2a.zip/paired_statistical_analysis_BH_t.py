#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Paired Statistical Analysis with Benjamini-Hochberg Correction

Performs comprehensive paired-sample statistical testing on before/after
metabolomics data, including normality tests, variance homogeneity,
paired t-test, and Wilcoxon signed-rank test, with two-stage variable
selection using raw p-value screening followed by BH correction.

Usage:
    python3 statistical_analysis_BH.py <input.csv> (Metabolite.csv)

Input CSV format (wide format):
    Column 1:       Variable name ('name')
    Columns 2-...:  Before_1, Before_2, ..., After_1, After_2, ...

Output (./Anal/ directory):
    Statistical_Results_Summary.csv           - Full results for all variables
    Step1_raw_p10_variables.csv               - Variables with raw p < 0.10
    Step2_Significant_BH10_variables.csv      - Final: BH-corrected p < 0.10

Statistical tests performed:
    - Shapiro-Wilk normality test (per group and combined)
    - Jarque-Bera normality test (requires n >= 8)
    - Levene's test for equality of variances
    - Paired t-test (primary test)
    - Wilcoxon signed-rank test (reference; note: minimum p = 0.125 for n < 6)

Two-stage selection strategy:
    Step 1: Screen variables by raw paired t-test p < 0.10
    Step 2: Apply BH correction only to Step 1 variables to avoid
            over-correction from the full variable set

Author: H. Miyamoto
"""

import sys
import os
import pandas as pd
import numpy as np
from scipy.stats import shapiro, jarque_bera, levene, ttest_rel, wilcoxon
from statsmodels.stats.multitest import multipletests
import warnings

warnings.filterwarnings("ignore")


# ===========================
# Command-line arguments
# ===========================
if len(sys.argv) != 2:
    print("Usage: python3 statistical_analysis_BH.py <input.csv>")
    sys.exit(1)

input_csv = sys.argv[1]

# ===========================
# Create output directory
# ===========================
os.makedirs("./Anal", exist_ok=True)

# ===========================
# Load data and standardise column names
# ===========================
df = pd.read_csv(input_csv)

# Standardise: Before_/Beforel_ -> Bef_, After_ -> Aft_
# (Beforel_ handled first to prevent partial match)
df.columns = [
    col.replace("Beforel_", "Bef_")
       .replace("Before_",  "Bef_")
       .replace("After_",   "Aft_")
    for col in df.columns
]

print("Column names (after standardisation):", df.columns.tolist())

gene_names = df['name'] if 'name' in df.columns else df.iloc[:, 0]

Control_d = df.filter(regex="^Bef_")
Test_d    = df.filter(regex="^Aft_")
n_genes   = df.shape[0]

print(f"Before columns: {Control_d.shape[1]}  |  After columns: {Test_d.shape[1]}")

if Control_d.shape[1] == 0 or Test_d.shape[1] == 0:
    print("ERROR: No Before/After columns found. Check column names.")
    sys.exit(1)

if Control_d.shape[1] != Test_d.shape[1]:
    print("WARNING: Unequal number of Before and After columns. "
          "This may affect paired tests.")


# ===========================
# BH correction helper
# Handles NaN values: corrects only valid p-values, restores original indices
# ===========================
def bh_correction(pvals_list):
    """Apply BH correction, skipping NaN values."""
    arr   = np.array(pvals_list, dtype=float)
    valid = ~np.isnan(arr)
    out   = np.full(len(arr), np.nan)
    if valid.sum() > 1:
        _, corrected, _, _ = multipletests(arr[valid], method='fdr_bh')
        out[valid] = corrected
    elif valid.sum() == 1:
        out[valid] = arr[valid]
    return out.tolist()


# ===========================
# Shapiro-Wilk & Jarque-Bera (combined Before + After)
# Note: Low statistical power at n=4; reported as reference
# ===========================
shapiro_all_p, shapiro_all_stat = [], []
jb_all_p, jb_all_stat = [], []

for i in range(n_genes):
    vec = pd.concat([Control_d.iloc[i], Test_d.iloc[i]]).dropna().astype(float)

    # Shapiro-Wilk (3 <= n <= 5000)
    if 3 <= len(vec) <= 5000 and len(np.unique(vec)) > 1:
        try:
            res = shapiro(vec)
            shapiro_all_p.append(res.pvalue)
            shapiro_all_stat.append(res.statistic)
        except Exception:
            shapiro_all_p.append(np.nan)
            shapiro_all_stat.append(np.nan)
    else:
        shapiro_all_p.append(np.nan)
        shapiro_all_stat.append(np.nan)

    # Jarque-Bera (requires n >= 8)
    if len(vec) >= 8 and len(np.unique(vec)) > 1:
        try:
            res = jarque_bera(vec)
            jb_all_p.append(res.pvalue)
            jb_all_stat.append(res.statistic)
        except Exception:
            jb_all_p.append(np.nan)
            jb_all_stat.append(np.nan)
    else:
        jb_all_p.append(np.nan)
        jb_all_stat.append(np.nan)


# ===========================
# Shapiro-Wilk & Jarque-Bera (per group)
# ===========================
shapiro_ctrl_p, shapiro_test_p = [], []
jb_ctrl_p, jb_test_p = [], []

for i in range(n_genes):
    xc = Control_d.iloc[i].dropna().astype(float)
    xt = Test_d.iloc[i].dropna().astype(float)

    # Shapiro-Wilk: Before
    if len(xc) >= 3 and len(np.unique(xc)) > 1 and len(xc) <= 5000:
        try:
            shapiro_ctrl_p.append(shapiro(xc).pvalue)
        except Exception:
            shapiro_ctrl_p.append(np.nan)
    else:
        shapiro_ctrl_p.append(np.nan)

    # Shapiro-Wilk: After
    if len(xt) >= 3 and len(np.unique(xt)) > 1 and len(xt) <= 5000:
        try:
            shapiro_test_p.append(shapiro(xt).pvalue)
        except Exception:
            shapiro_test_p.append(np.nan)
    else:
        shapiro_test_p.append(np.nan)

    # Jarque-Bera: Before (requires n >= 8)
    if len(np.unique(xc)) > 2 and len(xc) >= 8:
        try:
            jb_ctrl_p.append(jarque_bera(xc).pvalue)
        except Exception:
            jb_ctrl_p.append(np.nan)
    else:
        jb_ctrl_p.append(np.nan)

    # Jarque-Bera: After (requires n >= 8)
    if len(np.unique(xt)) > 2 and len(xt) >= 8:
        try:
            jb_test_p.append(jarque_bera(xt).pvalue)
        except Exception:
            jb_test_p.append(np.nan)
    else:
        jb_test_p.append(np.nan)


# ===========================
# Levene's test (equality of variances)
# Applicable to non-normal distributions
# ===========================
F_pvals = []
for i in range(n_genes):
    try:
        xc = Control_d.iloc[i].dropna().astype(float)
        xt = Test_d.iloc[i].dropna().astype(float)
        _, pval = levene(xc, xt)
        F_pvals.append(pval)
    except Exception:
        F_pvals.append(np.nan)


# ===========================
# Paired t-test & Wilcoxon signed-rank test
# Uses .values for position-based pairing (ignores column names)
# Note: Wilcoxon minimum p = 0.125 for n < 6; reported as reference
# ===========================
T_pvals, WT_pvals = [], []

for i in range(n_genes):
    x_arr = Control_d.iloc[i].values.astype(float)
    y_arr = Test_d.iloc[i].values.astype(float)
    mask  = ~np.isnan(x_arr) & ~np.isnan(y_arr)
    xp    = x_arr[mask]
    yp    = y_arr[mask]

    if len(xp) > 1:
        # Paired t-test (primary test)
        try:
            _, pval = ttest_rel(xp, yp)
            T_pvals.append(pval)
        except Exception:
            T_pvals.append(np.nan)

        # Wilcoxon signed-rank (reference)
        try:
            if np.all(xp == yp):
                WT_pvals.append(1.0)
            else:
                _, pval = wilcoxon(xp, yp)
                WT_pvals.append(pval)
        except Exception:
            WT_pvals.append(np.nan)
    else:
        T_pvals.append(np.nan)
        WT_pvals.append(np.nan)


# ===========================
# BH correction (applied to all tests)
# ===========================
shapiro_all_p_bh  = bh_correction(shapiro_all_p)
shapiro_ctrl_p_bh = bh_correction(shapiro_ctrl_p)
shapiro_test_p_bh = bh_correction(shapiro_test_p)
jb_all_p_bh       = bh_correction(jb_all_p)
jb_ctrl_p_bh      = bh_correction(jb_ctrl_p)
jb_test_p_bh      = bh_correction(jb_test_p)
F_pvals_bh        = bh_correction(F_pvals)
T_pvals_bh        = bh_correction(T_pvals)
WT_pvals_bh       = bh_correction(WT_pvals)


# ===========================
# Compile results (raw p-values and BH-corrected in parallel)
# ===========================
results = pd.DataFrame({
    "GeneID":                  gene_names.values,

    # --- Normality tests (reference) ---
    "Shapiro_Control_p":       shapiro_ctrl_p,
    "Shapiro_Control_p_BH":    shapiro_ctrl_p_bh,
    "Shapiro_Test_p":          shapiro_test_p,
    "Shapiro_Test_p_BH":       shapiro_test_p_bh,
    "Shapiro_All_p":           shapiro_all_p,
    "Shapiro_All_p_BH":        shapiro_all_p_bh,
    "Shapiro_All_W":           shapiro_all_stat,

    "JarqueBera_Control_p":    jb_ctrl_p,
    "JarqueBera_Control_p_BH": jb_ctrl_p_bh,
    "JarqueBera_Test_p":       jb_test_p,
    "JarqueBera_Test_p_BH":    jb_test_p_bh,
    "JarqueBera_All_p":        jb_all_p,
    "JarqueBera_All_p_BH":     jb_all_p_bh,
    "JarqueBera_All_X2":       jb_all_stat,

    # --- Variance homogeneity ---
    "Levene_p":                F_pvals,
    "Levene_p_BH":             F_pvals_bh,

    # --- Primary test: paired t-test ---
    "Ttest_paired_p":          T_pvals,
    "Ttest_paired_p_BH":       T_pvals_bh,

    # --- Reference: Wilcoxon (minimum p = 0.125 for n < 6) ---
    "Wilcoxon_paired_p":       WT_pvals,
    "Wilcoxon_paired_p_BH":    WT_pvals_bh,
})


# ===========================
# Two-stage variable selection
# Step 1: Screen by raw p < 0.10
# Step 2: Apply BH correction only to screened variables
#         (avoids over-correction from full variable set)
# ===========================
alpha_raw = 0.10   # Step 1 threshold
alpha_bh  = 0.10   # Step 2 threshold (BH-corrected)

# Step 1: Raw p-value screening
step1_df = results[results["Ttest_paired_p"] < alpha_raw].copy()
step1_df = step1_df.sort_values("Ttest_paired_p")

# Step 2: Recalculate BH correction on screened subset only
step1_pvals = step1_df["Ttest_paired_p"].values
if len(step1_pvals) > 1:
    _, bh_recalc, _, _ = multipletests(step1_pvals, method="fdr_bh")
    step1_df["Ttest_paired_p_BH_subset"] = bh_recalc
elif len(step1_pvals) == 1:
    step1_df["Ttest_paired_p_BH_subset"] = step1_pvals
else:
    step1_df["Ttest_paired_p_BH_subset"] = np.nan

# Step 3: Final selection by BH-corrected p < 0.10
sig_df = step1_df[step1_df["Ttest_paired_p_BH_subset"] < alpha_bh].copy()

output_all   = "./Anal/Statistical_Results_Summary.csv"
output_step1 = f"./Anal/Step1_raw_p{int(alpha_raw * 100)}_variables.csv"
output_sig   = f"./Anal/Step2_Significant_BH{int(alpha_bh * 100)}_variables.csv"

results.to_csv(output_all, index=False)
step1_df.to_csv(output_step1, index=False)
sig_df.to_csv(output_sig, index=False)


# ===========================
# Summary
# ===========================
print("\nAnalysis complete.")
print(f"  Full results:                    {output_all}")
print(f"  Step 1 (raw p < {alpha_raw}):           "
      f"{output_step1}  ({len(step1_df)} variables)")
print(f"  Step 2 (BH-corrected p < {alpha_bh}):   "
      f"{output_sig}  ({len(sig_df)} / {n_genes} variables)")

if len(sig_df) > 0:
    print("\n--- Final significant variables ---")
    print(sig_df[[
        "GeneID", "Ttest_paired_p", "Ttest_paired_p_BH_subset"
    ]].to_string(index=False))
else:
    print("\nNo significant variables after BH correction. "
          "Review Step 1 results.")
    if len(step1_df) > 0:
        print(f"\n--- Step 1 variables (raw p < {alpha_raw}) ---")
        print(step1_df[[
            "GeneID", "Ttest_paired_p"
        ]].to_string(index=False))
