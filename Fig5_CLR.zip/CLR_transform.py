#FileA.csv
#sample    K00001    K00002    K00003
#S1    10    30    60
#S2    0    20    80
#S3    5    5    90

#python3.10 clr_transform.py FileA.csv

import pandas as pd
import numpy as np
import sys
import os

def clr_transform(df, pseudocount=1e-6):
    """
    CLRtransformation（Centered Log-Ratio）
    df: DataFrame (numeric) for sample × feature
    """
    # Add pseudocount to avoid log(0)
    df = df + pseudocount

    # Calculate the geometric mean for each row (sample)
    geometric_means = df.apply(lambda row: np.exp(np.mean(np.log(row))), axis=1)

    # Divide by geometric mean to take log
    clr_df = df.div(geometric_means, axis=0).apply(np.log)

    return clr_df

# === コマンドライン引数処理 ===

if len(sys.argv) != 2:
    print("How to use: python3.10 clr_transform.py input_file.csv")
    sys.exit(1)

input_file = sys.argv[1]

if not os.path.isfile(input_file):
    print(f"Error: file '{input_file}' not found")
    sys.exit(1)

# Creating an Output File Name
base, ext = os.path.splitext(input_file)
output_file = f"{base}_clr.csv"

# === File Loading ===

try:
    df_raw = pd.read_csv(input_file)
except Exception as e:
    print(f"Error while loading CSV: {e}")
    sys.exit(1)

# Use the first column as the sample name
if 'sample' not in df_raw.columns[0].lower():
    print("error: The first column must contain the sample name (e.g., sample).")
    sys.exit(1)

df_raw = df_raw.set_index(df_raw.columns[0])

# 数値列のみ抽出
try:
    df_numeric = df_raw.astype(float)
except:
    print("error: Contains non-numerical data. All functional values must be numeric")
    sys.exit(1)

# === CLRtransformation ===
clr_df = clr_transform(df_numeric)

# Output the index back to the column
clr_df.insert(0, 'sample', clr_df.index)
clr_df.to_csv(output_file, index=False, float_format="%.15f") #指数変換しない設定にする

print(f"CLRtransformation: filename → {output_file}")
