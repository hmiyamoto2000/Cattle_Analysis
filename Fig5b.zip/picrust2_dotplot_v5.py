#!/usr/bin/env python3
"""
PICRUSt2 Comparison Chart v5
CLR converted data support
Same Body = Same Marker Shape, Before/After = Distinguish by Color
Object number on graph No text, identifying individuals with legends

How to use:
    python3 picrust2_dotplot_v5.py picrust2_clr.csv metadata.csv
"""

import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

plt.rcParams['font.family'] = 'Helvetica'
plt.rcParams['axes.linewidth'] = 1.5

# ============================================================
# fontsize setting
# ============================================================
FS_BASE     = 14
FS_TITLE    = 16
FS_SUPTITLE = 16
FS_TICK     = 12
FS_PVAL     = 11
FS_DELTA    = 12
FS_LEGEND   = 11
FS_YLABEL   = 14

plt.rcParams['font.size'] = FS_BASE

# ============================================================
# Command Line Arguments
# ============================================================
if len(sys.argv) != 3:
    print("How to use: python3 picrust2_dotplot_v5.py clr.csv metadata.csv")
    sys.exit(1)

picrust2_file = sys.argv[1]
metadata_file = sys.argv[2]

os.makedirs('./picrust2_dotplots', exist_ok=True)

# ============================================================
# Data Loading and Transposition Judgment
# ============================================================
df_raw  = pd.read_csv(picrust2_file, index_col=0)
df_meta = pd.read_csv(metadata_file, encoding='utf-8-sig')
df_meta.columns = ['sample', 'env', 'dir', 'ad']

col_match = len(set(df_raw.columns) & set(df_meta['sample']))
idx_match = len(set(df_raw.index)   & set(df_meta['sample']))
df_func   = df_raw.T if idx_match > col_match else df_raw

common  = list(set(df_func.columns) & set(df_meta['sample']))
df_func = df_func[common]
df_meta = df_meta[df_meta['sample'].isin(common)].reset_index(drop=True)

# ============================================================
# Individual ID Extraction
# The second from the back of the hyphen separator is animal_id
# Example: Miyamoto-D051-1293-1 → 1293
# ============================================================
def extract_animal_id(sample_name):
    parts = sample_name.split('-')
    if len(parts) >= 2:
        return parts[-2]
    return sample_name

df_meta['animal_id'] = df_meta['sample'].apply(extract_animal_id)
unique_animals = sorted(df_meta['animal_id'].unique())
print(f" List of animal IDs: {unique_animals}")

# ============================================================
# Assign markers to each individual (shape only)
# Distinguish groups by Before/After colors
# ============================================================
MARKERS       = ['o', '^', 's', 'D']   # ○ △ □ ◆
MARKER_LABELS = ['○', '△', '□', '◆']

animal_marker = {
    aid: MARKERS[i % len(MARKERS)]
    for i, aid in enumerate(unique_animals)
}
animal_label = {
    aid: MARKER_LABELS[i % len(MARKER_LABELS)]
    for i, aid in enumerate(unique_animals)
}

print(f"Marker Assignment:")
for aid in unique_animals:
    print(f"   {aid} → {animal_label[aid]}")

# ============================================================
# Color settings (colors for each group, marker shapes are common for individuals)
# ============================================================
COLOR_BEFORE = '#7F8C8D'   # Before → grey
COLOR_AFTER  = '#E74C3C'   # After  → red
COLOR_AD0    = '#3498DB'   # non_add → blue
COLOR_AD1    = '#E74C3C'   # add → red
COLOR_LINE   = '#BDC3C7'   # Corresponding lines

# ============================================================
# Get a sample
# ============================================================
def get_samples(filters):
    mask = pd.Series([True] * len(df_meta), index=df_meta.index)
    for col, val in filters.items():
        mask = mask & (df_meta[col] == val)
    return df_meta[mask]['sample'].tolist()

# ============================================================
# Significant EC number acquisition
# ============================================================
def get_significant_ecs(s1, s2, top_n=10):
    results = []
    for func in df_func.index:
        g1 = df_func.loc[func, s1].values.astype(float)
        g2 = df_func.loc[func, s2].values.astype(float)
        try:
            _, pval = stats.mannwhitneyu(g1, g2, alternative='two-sided')
        except:
            pval = np.nan
        if not np.isnan(pval):
            results.append({
                'function': func,
                'p_value':  pval,
                'mean1':    np.mean(g1),
                'mean2':    np.mean(g2)
            })
    df_r = pd.DataFrame(results).sort_values('p_value')
    sig  = df_r[df_r['p_value'] < 0.05]
    if len(sig) == 0:
        print("   p<0.05なし → p<0.1で再試行")
        sig = df_r[df_r['p_value'] < 0.1].head(top_n)
    print(f"   選抜EC数: {len(sig)}件")
    return sig.head(top_n)

# ============================================================
# Dot plot creation
# ・Same body → same marker shape
# ・Group (Before/After, etc.) → distinguish by color
# ・No individual number text on the graph
# ・Individual ID and marker shape are displayed in the legend
# ============================================================
def make_dotplot(ec_list, s1, s2,
                 label1, label2,
                 color1, color2,
                 title, output_name,
                 paired=False):

    if len(ec_list) == 0:
        print(f"  → ECnumber_non: skip")
        return

    n   = len(ec_list)
    fig, axes = plt.subplots(
        1, n,
        figsize=(4.5 * n, 5.5),
        squeeze=False
    )

    for col_idx, ec in enumerate(ec_list):
        ax = axes[0][col_idx]

        g1 = df_func.loc[ec, s1].values.astype(float)
        g2 = df_func.loc[ec, s2].values.astype(float)

        # 各サンプルの動物IDを取得
        animals1 = [
            df_meta.loc[df_meta['sample'] == s, 'animal_id'].values[0]
            for s in s1
        ]
        animals2 = [
            df_meta.loc[df_meta['sample'] == s, 'animal_id'].values[0]
            for s in s2
        ]

        try:
            _, pval = stats.mannwhitneyu(g1, g2, alternative='two-sided')
        except:
            pval = np.nan

        mean1 = np.mean(g1)
        mean2 = np.mean(g2)
        sem1  = stats.sem(g1)
        sem2  = stats.sem(g2)

        # Yaxis range
        all_vals = np.concatenate([g1, g2])
        y_min    = np.min(all_vals)
        y_max    = np.max(all_vals)
        y_range  = y_max - y_min if y_max != y_min else 1.0
        y_pad    = y_range * 0.15

        # 0 line
        ax.axhline(y=0, color='gray',
                   linestyle=':', linewidth=1.0,
                   alpha=0.5, zorder=1)

        # --------------------------------------------------------
        # Determine the jitter position first
        # --------------------------------------------------------
        np.random.seed(42)
        x_positions1 = {i: np.random.uniform(-0.08, 0.08)
                        for i in range(len(g1))}
        x_positions2 = {i: 1 + np.random.uniform(-0.08, 0.08)
                        for i in range(len(g2))}

        # --------------------------------------------------------
        # Correspondence line (same Before→After
        # paired=True and tie pairs with matching animal IDs
        # --------------------------------------------------------
        if paired:
            aid_to_idx1 = {aid: i for i, aid in enumerate(animals1)}
            for j, aid2 in enumerate(animals2):
                if aid2 in aid_to_idx1:
                    i = aid_to_idx1[aid2]
                    ax.plot(
                        [x_positions1[i], x_positions2[j]],
                        [g1[i], g2[j]],
                        color=COLOR_LINE,
                        linewidth=1.2,
                        alpha=0.6, zorder=2
                    )

        # --------------------------------------------------------
        # # Individual Dot Drawing
        # Same body = same marker shape
        # Group (Before/After) = Distinguish by color
        # No text labels on the graph        # --------------------------------------------------------
        for i, (val, aid) in enumerate(zip(g1, animals1)):
            mk = animal_marker.get(aid, 'o')
            xp = x_positions1[i]
            ax.scatter(xp, val,
                       marker=mk,
                       color=color1,
                       s=110,
                       edgecolors='white',
                       linewidths=1.2,
                       zorder=5, alpha=0.9)

        for j, (val, aid) in enumerate(zip(g2, animals2)):
            mk = animal_marker.get(aid, 'o')
            xp = x_positions2[j]
            ax.scatter(xp, val,
                       marker=mk,
                       color=color2,
                       s=110,
                       edgecolors='white',
                       linewidths=1.2,
                       zorder=5, alpha=0.9)

        # --------------------------------------------------------
        # mean ± SEM
        # --------------------------------------------------------
        ax.errorbar(
            [0, 1], [mean1, mean2],
            yerr=[sem1, sem2],
            fmt='none',
            ecolor='black',
            elinewidth=2.0,
            capsize=5,
            capthick=2.0,
            zorder=6
        )
        ax.plot(
            [0, 1], [mean1, mean2],
            'o-', color='black',
            linewidth=2.0, markersize=9,
            markerfacecolor='black',
            markeredgecolor='white',
            markeredgewidth=1.5,
            zorder=7
        )

        # --------------------------------------------------------
        # P-Value Bracket
        # --------------------------------------------------------
        if not np.isnan(pval):
            bracket = y_max + y_pad
            ax.plot(
                [0, 0, 1, 1],
                [bracket * 0.97, bracket, bracket, bracket * 0.97],
                color='black', linewidth=1.2, zorder=8
            )
            if pval < 0.001:   star = '***'
            elif pval < 0.01:  star = f'** p={pval:.3f}'
            elif pval < 0.05:  star = f'* p={pval:.3f}'
            else:              star = f'p={pval:.3f}'

            ax.text(0.5, bracket * 1.01, star,
                    ha='center', va='bottom',
                    fontsize=FS_PVAL, fontweight='bold', zorder=9)

        # Yaxis range
        ax.set_ylim(y_min - y_pad * 1.5,
                    y_max + y_pad * 4.0)

        # Δ indicated
        diff     = mean2 - mean1
        arrow    = '(+)' if diff > 0 else '(-)'
        fc_color = color2 if diff > 0 else color1
        ax.text(0.5, 0.02,
                f'{arrow} mean diff = {diff:.3f}',
                transform=ax.transAxes,
                ha='center', va='bottom',
                fontsize=FS_DELTA, color=fc_color,
                fontweight='bold')

        # axis setting
        ax.set_xticks([0, 1])
        ax.set_xticklabels(
            [f'{label1}\n(n={len(g1)})',
             f'{label2}\n(n={len(g2)})'],
            fontsize=FS_TICK
        )
        ax.set_ylabel(
            'CLR-transformed abundance\n(PICRUSt2)',
            fontsize=FS_YLABEL
        )
        ax.set_title(ec, fontsize=FS_TITLE,
                     fontweight='bold', pad=10)
        ax.yaxis.grid(True, linestyle='--', alpha=0.3, zorder=0)
        ax.set_axisbelow(True)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    # ============================================================
    # Legend: Marker shape = individual ID, color = group (Before/After)
    # ============================================================
    # Marker legend of individual IDs (uniformly displayed in gray)
    marker_handles = [
        plt.Line2D(
            [0], [0],
            marker=MARKERS[i % len(MARKERS)],
            color='w',
            markerfacecolor='dimgray',
            markeredgecolor='dimgray',
            markersize=FS_LEGEND,
            label=f'{unique_animals[i]}'
        )
        for i in range(len(unique_animals))
    ]
    # group legend
    color_handles = [
        plt.Line2D(
            [0], [0],
            marker='o', color='w',
            markerfacecolor=color1,
            markeredgecolor='white',
            markersize=FS_LEGEND,
            label=label1.replace('\n', ' ')
        ),
        plt.Line2D(
            [0], [0],
            marker='o', color='w',
            markerfacecolor=color2,
            markeredgecolor='white',
            markersize=FS_LEGEND,
            label=label2.replace('\n', ' ')
        ),
    ]

    # Place the legend in 2 blocks at the top left
    leg1 = fig.legend(
        handles=marker_handles,
        loc='upper left',
        bbox_to_anchor=(0.01, 0.98),
        bbox_transform=fig.transFigure,
        fontsize=FS_LEGEND,
        frameon=True,
        framealpha=0.9,
        edgecolor='lightgray',
        title='Animal ID',
        title_fontsize=FS_LEGEND,
        borderpad=0.8,
        handletextpad=0.5
    )
    fig.add_artist(leg1)   # Keep the first legend

    fig.legend(
        handles=color_handles,
        loc='upper left',
        bbox_to_anchor=(0.01, 0.70),
        bbox_transform=fig.transFigure,
        fontsize=FS_LEGEND,
        frameon=True,
        framealpha=0.9,
        edgecolor='lightgray',
        title='Group',
        title_fontsize=FS_LEGEND,
        borderpad=0.8,
        handletextpad=0.5
    )

    fig.suptitle(title, fontsize=FS_SUPTITLE,
                 fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.subplots_adjust(left=0.15)

    pdf_out = f'./picrust2_dotplots/{output_name}.pdf'
    png_out = f'./picrust2_dotplots/{output_name}.png'
    plt.savefig(pdf_out, bbox_inches='tight', dpi=300)
    plt.savefig(png_out, bbox_inches='tight', dpi=300)
    plt.close()
    print(f"  save: {pdf_out}")

# ============================================================
# Performing Analysis
# ============================================================
print("\n Performing Analysis...")

# ① Before vs After
s1 = get_samples({'env': 'before'})
s2 = get_samples({'env': 'after'})
print(f"\n before(n={len(s1)}) vs after(n={len(s2)})")
if s1 and s2:
    sig = get_significant_ecs(s1, s2)
    make_dotplot(
        sig['function'].tolist(), s1, s2,
        'Before', 'After',
        COLOR_BEFORE, COLOR_AFTER,
        'Before vs After (CLR-transformed PICRUSt2)',
        '01_before_vs_after',
        paired=True
    )

# ② non_administration vs administration
s1 = get_samples({'ad': 0})
s2 = get_samples({'ad': 1})
print(f"\n non_administration(n={len(s1)}) vs non_administration(n={len(s2)})")
if s1 and s2:
    sig = get_significant_ecs(s1, s2)
    make_dotplot(
        sig['function'].tolist(), s1, s2,
        'Control\n(ad=0)', 'Administered\n(ad=1)',
        COLOR_AD0, COLOR_AD1,
        'Control vs Administered (CLR-transformed PICRUSt2)',
        '02_ad0_vs_ad1',
        paired=True
    )

print(f"\nfinished: ./picrust2_dotplots/")
