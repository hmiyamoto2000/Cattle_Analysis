#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Permutation Test for ROC AUC Validation

Assesses whether observed ROC AUC values for selected feature
metabolites significantly exceed those expected by chance,
addressing the concern of in-sample overfitting at small sample
sizes (n=6).

Usage:
    python3 roc_permutation_test.py <metabolite_data.csv> <selected_features.csv>

Arguments:
    metabolite_data.csv    - Metabolite abundance data
                             Column 1: metabolite name
                             Remaining columns: sample values
                             Column names must contain "Before" or "After"

    selected_features.csv  - List of selected feature metabolites
                             (output from Cliff's delta pipeline)
                             Must contain a column named "GeneID" or
                             first column used as feature names

Output:
    ./Permutation_ROC/
        permutation_roc_results.csv      - Full results with p-values
        permutation_roc_significant.csv  - Significant results (p < 0.05)
        permutation_histogram_<name>.pdf - Null distribution histograms
        permutation_summary.txt          - Summary statistics

Statistical method:
    For each selected metabolite:
    1. Calculate the observed AUC using true Before/After labels
    2. Randomly permute group labels 10,000 times
    3. Calculate AUC for each permutation
    4. p-value = proportion of permuted AUCs >= observed AUC

Author: H. Miyamoto
Note: Developed with AI assistance (Claude, Anthropic).
      All code reviewed and validated by the author.
"""

import sys
import os
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

plt.rcParams['font.family'] = 'Helvetica'
plt.rcParams['font.size'] = 12


# ============================================================
# 1. Load data
# ============================================================
def load_data(metabolite_file, feature_file):
    print("\n" + "=" * 60)
    print("Loading data...")
    print("=" * 60)

    # Load metabolite data
    df = pd.read_csv(metabolite_file, index_col=0)

    # Determine Before/After columns
    before_cols = [c for c in df.columns if 'Before' in c or 'Bef' in c]
    after_cols = [c for c in df.columns if 'After' in c or 'Aft' in c]

    if not before_cols or not after_cols:
        # Try alternative: columns with specific patterns
        before_cols = [c for c in df.columns if 'before' in c.lower()]
        after_cols = [c for c in df.columns if 'after' in c.lower()]

    print(f"  Before columns (n={len(before_cols)}): {before_cols}")
    print(f"  After columns  (n={len(after_cols)}):  {after_cols}")

    if not before_cols or not after_cols:
        print("ERROR: Could not identify Before/After columns.")
        print(f"  Available columns: {df.columns.tolist()}")
        sys.exit(1)

    # Load selected features
    df_feat = pd.read_csv(feature_file)
    if 'GeneID' in df_feat.columns:
        features = df_feat['GeneID'].tolist()
    elif 'name' in df_feat.columns:
        features = df_feat['name'].tolist()
    elif 'function' in df_feat.columns:
        features = df_feat['function'].tolist()
    else:
        features = df_feat.iloc[:, 0].tolist()

    # Filter to features present in metabolite data
    features = [f for f in features if f in df.index]
    print(f"  Selected features found in data: {len(features)}")

    return df, before_cols, after_cols, features


# ============================================================
# 2. Calculate ROC AUC
# ============================================================
def calc_auc(values_before, values_after):
    """
    Calculate ROC AUC for a single metabolite.
    Labels: Before=0, After=1
    Returns AUC (max of AUC and 1-AUC to handle direction)
    """
    y_true = np.array([0] * len(values_before) + [1] * len(values_after))
    y_score = np.concatenate([values_before, values_after])

    # Remove NaN
    mask = ~np.isnan(y_score)
    y_true = y_true[mask]
    y_score = y_score[mask]

    if len(np.unique(y_true)) < 2:
        return np.nan

    try:
        auc = roc_auc_score(y_true, y_score)
        # Take the maximum of AUC and 1-AUC (direction-independent)
        return max(auc, 1 - auc)
    except Exception:
        return np.nan


# ============================================================
# 3. Permutation test
# ============================================================
def permutation_test(df, before_cols, after_cols, feature,
                     n_permutations=10000, seed=42):
    """
    Perform permutation test for a single metabolite.
    Randomly shuffles Before/After labels and recalculates AUC.
    """
    np.random.seed(seed)

    # Get observed values
    val_before = df.loc[feature, before_cols].values.astype(float)
    val_after = df.loc[feature, after_cols].values.astype(float)

    # Observed AUC
    observed_auc = calc_auc(val_before, val_after)

    if np.isnan(observed_auc):
        return observed_auc, np.nan, np.array([])

    # Combine all values
    all_values = np.concatenate([val_before, val_after])
    n_before = len(val_before)
    n_total = len(all_values)

    # Permutation
    perm_aucs = np.zeros(n_permutations)

    for i in range(n_permutations):
        # Shuffle indices
        perm_idx = np.random.permutation(n_total)
        perm_before = all_values[perm_idx[:n_before]]
        perm_after = all_values[perm_idx[n_before:]]
        perm_aucs[i] = calc_auc(perm_before, perm_after)

    # p-value: proportion of permuted AUCs >= observed AUC
    p_value = np.mean(perm_aucs >= observed_auc)

    return observed_auc, p_value, perm_aucs


# ============================================================
# 4. Plot null distribution
# ============================================================
def plot_null_distribution(feature_name, observed_auc, perm_aucs,
                           p_value, output_dir):
    """
    Plot histogram of permuted AUC values with observed AUC marked.
    """
    fig, ax = plt.subplots(figsize=(6, 4))

    ax.hist(perm_aucs, bins=50, color='steelblue', alpha=0.7,
            edgecolor='white', linewidth=0.5, density=True,
            label='Permuted AUC\n(null distribution)')

    ax.axvline(observed_auc, color='red', linewidth=2,
               linestyle='--',
               label=f'Observed AUC = {observed_auc:.3f}')

    # Shade p-value region
    ax.fill_betweenx(
        [0, ax.get_ylim()[1] * 1.1],
        observed_auc, 1.0,
        alpha=0.15, color='red'
    )

    ax.set_xlabel('AUC', fontsize=14)
    ax.set_ylabel('Density', fontsize=14)
    ax.set_xlim(0.4, 1.05)

    # Clean feature name for title
    title_name = feature_name[:50] if len(feature_name) > 50 else feature_name
    ax.set_title(f'{title_name}\n(permutation p = {p_value:.4f})',
                 fontsize=12, fontweight='bold')

    ax.legend(loc='upper left', fontsize=10)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()

    # Safe filename
    safe_name = "".join(c if c.isalnum() or c in '-_' else '_'
                        for c in feature_name)[:60]

    pdf_out = os.path.join(output_dir, f'permutation_{safe_name}.pdf')
    png_out = os.path.join(output_dir, f'permutation_{safe_name}.png')
    plt.savefig(pdf_out, bbox_inches='tight', dpi=300)
    plt.savefig(png_out, bbox_inches='tight', dpi=300)
    plt.close()

    return pdf_out


# ============================================================
# 5. Main analysis
# ============================================================
def main():
    if len(sys.argv) != 3:
        print("Usage: python3 roc_permutation_test.py "
              "<metabolite_data.csv> <selected_features.csv>")
        sys.exit(1)

    metabolite_file = sys.argv[1]
    feature_file = sys.argv[2]

    N_PERM = 10000

    print("\n" + "=" * 60)
    print("ROC AUC Permutation Test")
    print("=" * 60)
    print(f"Metabolite data:   {metabolite_file}")
    print(f"Selected features: {feature_file}")
    print(f"Permutations:      {N_PERM}")

    # Output directory
    output_dir = './Permutation_ROC'
    os.makedirs(output_dir, exist_ok=True)

    # Load data
    df, before_cols, after_cols, features = load_data(
        metabolite_file, feature_file)

    print(f"\n  Total samples: {len(before_cols) + len(after_cols)} "
          f"(Before={len(before_cols)}, After={len(after_cols)})")
    print(f"  Features to test: {len(features)}")

    # Run permutation test for each feature
    print("\n" + "=" * 60)
    print(f"Running permutation tests ({N_PERM} permutations each)...")
    print("=" * 60)

    results = []

    for i, feature in enumerate(features):
        print(f"\n  [{i+1}/{len(features)}] {feature[:60]}")

        observed_auc, p_value, perm_aucs = permutation_test(
            df, before_cols, after_cols, feature,
            n_permutations=N_PERM)

        if np.isnan(observed_auc):
            print(f"    Skipped (insufficient data)")
            continue

        # Mean and SD of null distribution
        null_mean = np.mean(perm_aucs)
        null_sd = np.std(perm_aucs)

        print(f"    Observed AUC: {observed_auc:.3f}")
        print(f"    Null distribution: mean={null_mean:.3f}, "
              f"SD={null_sd:.3f}")
        print(f"    Permutation p-value: {p_value:.4f}"
              f"{'  *' if p_value < 0.05 else ''}"
              f"{'**' if p_value < 0.01 else ''}"
              f"{'*' if p_value < 0.001 else ''}")

        # Plot
        pdf_path = plot_null_distribution(
            feature, observed_auc, perm_aucs, p_value, output_dir)
        print(f"    Plot: {pdf_path}")

        results.append({
            'feature': feature,
            'observed_AUC': observed_auc,
            'null_mean_AUC': null_mean,
            'null_SD_AUC': null_sd,
            'permutation_p_value': p_value,
            'n_permutations': N_PERM,
            'n_before': len(before_cols),
            'n_after': len(after_cols),
            'significant_005': 'yes' if p_value < 0.05 else 'no'
        })

    # Save results
    print("\n" + "=" * 60)
    print("Saving results...")
    print("=" * 60)

    df_results = pd.DataFrame(results)
    df_results = df_results.sort_values('permutation_p_value')

    # Full results
    out_all = os.path.join(output_dir, 'permutation_roc_results.csv')
    df_results.to_csv(out_all, index=False)
    print(f"  Full results:   {out_all}")

    # Significant results
    df_sig = df_results[df_results['permutation_p_value'] < 0.05]
    out_sig = os.path.join(output_dir,
                           'permutation_roc_significant.csv')
    df_sig.to_csv(out_sig, index=False)
    print(f"  Significant:    {out_sig} ({len(df_sig)} features)")

    # Summary text
    out_summary = os.path.join(output_dir, 'permutation_summary.txt')
    with open(out_summary, 'w') as f:
        f.write("ROC AUC Permutation Test Summary\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Metabolite data:    {metabolite_file}\n")
        f.write(f"Selected features:  {feature_file}\n")
        f.write(f"N permutations:     {N_PERM}\n")
        f.write(f"N before samples:   {len(before_cols)}\n")
        f.write(f"N after samples:    {len(after_cols)}\n")
        f.write(f"Total features tested: {len(results)}\n")
        f.write(f"Significant (p < 0.05): {len(df_sig)}\n\n")

        f.write("Results (sorted by p-value):\n")
        f.write("-" * 60 + "\n")
        for _, row in df_results.iterrows():
            f.write(f"  {row['feature'][:50]}\n")
            f.write(f"    AUC = {row['observed_AUC']:.3f}, "
                    f"p = {row['permutation_p_value']:.4f}")
            if row['permutation_p_value'] < 0.05:
                f.write(" *")
            if row['permutation_p_value'] < 0.01:
                f.write("*")
            if row['permutation_p_value'] < 0.001:
                f.write("*")
            f.write("\n")
            f.write(f"    Null: mean={row['null_mean_AUC']:.3f}, "
                    f"SD={row['null_SD_AUC']:.3f}\n\n")

        f.write("\nInterpretation:\n")
        f.write("-" * 60 + "\n")
        f.write("The permutation p-value represents the probability\n")
        f.write("of observing an AUC as extreme as the observed value\n")
        f.write("under the null hypothesis (no difference between\n")
        f.write("Before and After groups). A significant p-value\n")
        f.write("indicates that the observed group separation exceeds\n")
        f.write("what would be expected by chance, even at this small\n")
        f.write("sample size (n = "
                f"{len(before_cols) + len(after_cols)}).\n\n")
        f.write("Note: These results reflect in-sample separation\n")
        f.write("and should not be interpreted as evidence of\n")
        f.write("predictive performance or generalisability.\n")

    print(f"  Summary:        {out_summary}")

    # Final summary
    print("\n" + "=" * 60)
    print("Analysis complete.")
    print("=" * 60)
    print(f"\n  Features tested:       {len(results)}")
    print(f"  Significant (p < 0.05): {len(df_sig)}")
    if len(df_sig) > 0:
        print("\n  Significant features:")
        for _, row in df_sig.iterrows():
            print(f"    {row['feature'][:50]}")
            print(f"      AUC = {row['observed_AUC']:.3f}, "
                  f"p = {row['permutation_p_value']:.4f}")


if __name__ == '__main__':
    main()
