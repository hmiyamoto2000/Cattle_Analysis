#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exact Permutation Test for ROC AUC

For n=4 vs n=4 (Before vs After), all C(8,4) = 70 possible
label assignments are enumerated to calculate exact p-values.
This is more rigorous than random permutation for small samples.

Usage:
    python3 roc_exact_permutation.py <metabolite_data.csv> <selected_features.csv>

Arguments:
    metabolite_data.csv    - Metabolite abundance data
                             Column 1: metabolite name
                             Remaining columns: sample values
                             Column names must contain "Before" or "After"

    selected_features.csv  - List of selected feature metabolites
                             Must contain a column named "GeneID", "name",
                             "function", or first column used as feature names

Output:
    ./Exact_Permutation/
        exact_permutation_results.csv       - Full results
        exact_permutation_significant.csv   - Significant (p < 0.05)
        exact_permutation_histogram_<name>.pdf - Null distribution
        exact_permutation_summary.txt       - Summary

Statistical method:
    For each selected metabolite:
    1. Calculate observed AUC using true Before/After labels
    2. Enumerate all C(8,4) = 70 possible label assignments
    3. Calculate AUC for each assignment
    4. Exact p-value = count(permuted AUC >= observed AUC) / 70

Author: H. Miyamoto
Note: Developed with AI assistance (Claude, Anthropic).
      All code reviewed and validated by the author.
"""

import sys
import os
import pandas as pd
import numpy as np
from itertools import combinations
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

plt.rcParams['font.family'] = 'Helvetica'
plt.rcParams['font.size'] = 12


# ============================================================
# 1. Load data
# ============================================================
def load_data(metabolite_file, feature_file):
    print("\n" + "=" * 60)
    print("Loading data...")
    print("=" * 60)

    df = pd.read_csv(metabolite_file, index_col=0)

    before_cols = [c for c in df.columns if 'Before' in c or 'Bef' in c]
    after_cols = [c for c in df.columns if 'After' in c or 'Aft' in c]

    if not before_cols or not after_cols:
        before_cols = [c for c in df.columns if 'before' in c.lower()]
        after_cols = [c for c in df.columns if 'after' in c.lower()]

    print(f"  Before columns (n={len(before_cols)}): {before_cols}")
    print(f"  After columns  (n={len(after_cols)}):  {after_cols}")

    if not before_cols or not after_cols:
        print("ERROR: Could not identify Before/After columns.")
        sys.exit(1)

    df_feat = pd.read_csv(feature_file)
    if 'GeneID' in df_feat.columns:
        features = df_feat['GeneID'].tolist()
    elif 'name' in df_feat.columns:
        features = df_feat['name'].tolist()
    elif 'function' in df_feat.columns:
        features = df_feat['function'].tolist()
    else:
        features = df_feat.iloc[:, 0].tolist()

    features = [f for f in features if f in df.index]
    print(f"  Selected features found in data: {len(features)}")

    return df, before_cols, after_cols, features


# ============================================================
# 2. Calculate ROC AUC (direction-independent)
# ============================================================
def calc_auc(values_group0, values_group1):
    y_true = np.array([0] * len(values_group0) + [1] * len(values_group1))
    y_score = np.concatenate([values_group0, values_group1])

    mask = ~np.isnan(y_score)
    y_true = y_true[mask]
    y_score = y_score[mask]

    if len(np.unique(y_true)) < 2:
        return np.nan

    try:
        auc = roc_auc_score(y_true, y_score)
        return max(auc, 1 - auc)
    except Exception:
        return np.nan


# ============================================================
# 3. Exact permutation test
# ============================================================
def exact_permutation_test(df, before_cols, after_cols, feature):
    val_before = df.loc[feature, before_cols].values.astype(float)
    val_after = df.loc[feature, after_cols].values.astype(float)

    # Observed AUC
    observed_auc = calc_auc(val_before, val_after)

    if np.isnan(observed_auc):
        return observed_auc, np.nan, np.array([]), 0, 0

    # All values combined
    all_values = np.concatenate([val_before, val_after])
    n_total = len(all_values)
    n_before = len(val_before)

    # Enumerate all C(n_total, n_before) combinations
    all_indices = list(range(n_total))
    all_combos = list(combinations(all_indices, n_before))
    n_perms = len(all_combos)

    perm_aucs = np.zeros(n_perms)

    for i, combo in enumerate(all_combos):
        perm_before = all_values[list(combo)]
        perm_after_idx = [j for j in all_indices if j not in combo]
        perm_after = all_values[perm_after_idx]
        perm_aucs[i] = calc_auc(perm_before, perm_after)

    # Exact p-value
    n_ge = int(np.sum(perm_aucs >= observed_auc - 1e-10))
    exact_p = n_ge / n_perms

    return observed_auc, exact_p, perm_aucs, n_ge, n_perms


# ============================================================
# 4. Plot null distribution
# ============================================================
def plot_null_distribution(feature_name, observed_auc, perm_aucs,
                           n_ge, n_perms, exact_p, output_dir):
    fig, ax = plt.subplots(figsize=(6, 4))

    # Count unique AUC values for bar plot
    unique_aucs, counts = np.unique(perm_aucs, return_counts=True)

    ax.bar(unique_aucs, counts, width=0.03,
           color='steelblue', alpha=0.7,
           edgecolor='white', linewidth=0.5,
           label=f'All {n_perms} permutations')

    ax.axvline(observed_auc, color='red', linewidth=2.0,
               linestyle='--',
               label=f'Observed AUC = {observed_auc:.3f}')

    # Shade p-value region
    ymax = ax.get_ylim()[1]
    ax.fill_betweenx([0, ymax * 1.1],
                     observed_auc, 1.05,
                     alpha=0.15, color='red')

    ax.set_xlabel('AUC', fontsize=14)
    ax.set_ylabel('Count', fontsize=14)
    ax.set_xlim(0.4, 1.05)

    title_name = feature_name[:50] if len(feature_name) > 50 else feature_name
    ax.set_title(f'{title_name}\n'
                 f'(exact p = {n_ge}/{n_perms} = {exact_p:.3f})',
                 fontsize=12, fontweight='bold')

    ax.legend(loc='upper left', fontsize=10)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()

    safe_name = "".join(c if c.isalnum() or c in '-_' else '_'
                        for c in feature_name)[:60]

    pdf_out = os.path.join(output_dir, f'exact_perm_{safe_name}.pdf')
    png_out = os.path.join(output_dir, f'exact_perm_{safe_name}.png')
    plt.savefig(pdf_out, bbox_inches='tight', dpi=300)
    plt.savefig(png_out, bbox_inches='tight', dpi=300)
    plt.close()

    return pdf_out


# ============================================================
# 5. Main
# ============================================================
def main():
    if len(sys.argv) != 3:
        print("Usage: python3 roc_exact_permutation.py "
              "<metabolite_data.csv> <selected_features.csv>")
        sys.exit(1)

    metabolite_file = sys.argv[1]
    feature_file = sys.argv[2]

    print("\n" + "=" * 60)
    print("ROC AUC Exact Permutation Test")
    print("=" * 60)
    print(f"Metabolite data:   {metabolite_file}")
    print(f"Selected features: {feature_file}")

    output_dir = './Exact_Permutation'
    os.makedirs(output_dir, exist_ok=True)

    df, before_cols, after_cols, features = load_data(
        metabolite_file, feature_file)

    n_total = len(before_cols) + len(after_cols)
    n_before = len(before_cols)
    from math import comb
    n_combos = comb(n_total, n_before)

    print(f"\n  Total samples: {n_total} "
          f"(Before={len(before_cols)}, After={len(after_cols)})")
    print(f"  Total permutations: C({n_total},{n_before}) = {n_combos}")
    print(f"  Features to test: {len(features)}")

    print("\n" + "=" * 60)
    print(f"Running exact permutation tests ({n_combos} permutations each)...")
    print("=" * 60)

    results = []

    for i, feature in enumerate(features):
        print(f"\n  [{i+1}/{len(features)}] {feature[:60]}")

        observed_auc, exact_p, perm_aucs, n_ge, n_perms = \
            exact_permutation_test(df, before_cols, after_cols, feature)

        if np.isnan(observed_auc):
            print(f"    Skipped (insufficient data)")
            continue

        null_mean = np.mean(perm_aucs)
        null_sd = np.std(perm_aucs)

        print(f"    Observed AUC: {observed_auc:.3f}")
        print(f"    Null distribution: mean={null_mean:.3f}, "
              f"SD={null_sd:.3f}")
        print(f"    Exact p = {n_ge}/{n_perms} = {exact_p:.4f}"
              f"{'  *' if exact_p < 0.05 else ''}")

        pdf_path = plot_null_distribution(
            feature, observed_auc, perm_aucs,
            n_ge, n_perms, exact_p, output_dir)
        print(f"    Plot: {pdf_path}")

        results.append({
            'feature': feature,
            'observed_AUC': observed_auc,
            'null_mean_AUC': null_mean,
            'null_SD_AUC': null_sd,
            'n_ge': n_ge,
            'n_permutations': n_perms,
            'exact_p_value': exact_p,
            'n_before': len(before_cols),
            'n_after': len(after_cols),
            'significant_005': 'yes' if exact_p < 0.05 else 'no'
        })

    # Save results
    print("\n" + "=" * 60)
    print("Saving results...")
    print("=" * 60)

    df_results = pd.DataFrame(results)
    df_results = df_results.sort_values('exact_p_value')

    out_all = os.path.join(output_dir, 'exact_permutation_results.csv')
    df_results.to_csv(out_all, index=False)
    print(f"  Full results:   {out_all}")

    df_sig = df_results[df_results['exact_p_value'] < 0.05]
    out_sig = os.path.join(output_dir, 'exact_permutation_significant.csv')
    df_sig.to_csv(out_sig, index=False)
    print(f"  Significant:    {out_sig} ({len(df_sig)} features)")

    # Summary
    out_summary = os.path.join(output_dir, 'exact_permutation_summary.txt')
    with open(out_summary, 'w') as f:
        f.write("ROC AUC Exact Permutation Test Summary\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Metabolite data:    {metabolite_file}\n")
        f.write(f"Selected features:  {feature_file}\n")
        f.write(f"N before samples:   {len(before_cols)}\n")
        f.write(f"N after samples:    {len(after_cols)}\n")
        f.write(f"Total permutations: C({n_total},{n_before}) = {n_combos}\n")
        f.write(f"Total features tested: {len(results)}\n")
        f.write(f"Significant (p < 0.05): {len(df_sig)}\n\n")

        f.write("Results (sorted by p-value):\n")
        f.write("-" * 60 + "\n")
        for _, row in df_results.iterrows():
            f.write(f"  {row['feature'][:50]}\n")
            f.write(f"    AUC = {row['observed_AUC']:.3f}, "
                    f"exact p = {int(row['n_ge'])}/{int(row['n_permutations'])}"
                    f" = {row['exact_p_value']:.4f}")
            if row['exact_p_value'] < 0.05:
                f.write(" *")
            f.write("\n\n")

        f.write("\nInterpretation:\n")
        f.write("-" * 60 + "\n")
        f.write(f"All C({n_total},{n_before}) = {n_combos} possible\n")
        f.write("group label assignments were enumerated.\n")
        f.write("The exact p-value represents the proportion of\n")
        f.write("permutations yielding AUC values equal to or\n")
        f.write("exceeding the observed AUC.\n\n")
        f.write("Note: These results reflect in-sample separation\n")
        f.write("and should not be interpreted as evidence of\n")
        f.write("predictive performance or generalisability.\n")

    print(f"  Summary:        {out_summary}")

    # Final summary
    print("\n" + "=" * 60)
    print("Analysis complete.")
    print("=" * 60)
    print(f"\n  Features tested:       {len(results)}")
    print(f"  Total permutations:    {n_combos}")
    print(f"  Significant (p < 0.05): {len(df_sig)}")
    if len(df_sig) > 0:
        print("\n  Significant features:")
        for _, row in df_sig.iterrows():
            print(f"    {row['feature'][:50]}")
            print(f"      AUC = {row['observed_AUC']:.3f}, "
                  f"exact p = {int(row['n_ge'])}/{int(row['n_permutations'])}"
                  f" = {row['exact_p_value']:.4f}")


if __name__ == '__main__':
    main()
